/*
 * File:   main.c
 * Author: s2vd
 *
 * Created on February 20, 2010, 3:06 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#define heads_file "head.txt"
#define dataset "url2.txt"
#define URL_LENGTH 200
#define B_VEC_SIZE 80

struct dataset_file
{
    char *html_name;
    char *url_name;
    unsigned long long uid;
    struct dataset_file *link;
}*root_dataset,*current_dataset;

struct head
{
    unsigned long long uid;
    unsigned short *bit_vector;
    struct head *next_head;
    struct childs *childs_list;
}*root_head,*current_head;

struct childs
{
    unsigned short *masked_bit_vector;
    unsigned short *encoded_bit_vector;
    struct childs *next_child;
};

unsigned short prev_bit=0,mbn=3,no_of_bits=0,cnt_flag=1;


void hypergraph_gen();
char *find_html_for_uid(unsigned long long );
char *find_url_for_uid(unsigned long long);
char *does_it_end_with_html(char *);
struct head *add_head(char *);
void create_dataset();
struct dataset_file *add_node(char *,char *,unsigned long long);
struct childs *add_child_to_head(unsigned long long );
unsigned find_bit_in_position(unsigned ,struct head *);
unsigned short *gen_bitvector(char *, unsigned short *);
void set_bit(unsigned long long ,unsigned short *);
char *get_out_filename_for_uid(char *);
struct childs *add_child(char *, unsigned short *);
struct childs *gen_childs(char *, unsigned short *);
void display_heads();
unsigned short *gen_masked_bitvector(char *,char *);
void run_length_encoded_bitvector(struct childs *);
void compare_wit_prev_bit(unsigned short ,struct childs *);
void encode(unsigned short , unsigned short ,struct childs *);
void convert_to_binary(unsigned short);
void start_encoding();
void first_one(unsigned short ,struct childs *);
int main(int argc, char** argv)
{
    create_dataset();
    hypergraph_gen();
    
    start_encoding();
display_heads();
    return (EXIT_SUCCESS);
}

void create_dataset()
{
    FILE *fp_dataset;
    char *hname,*uname;
    unsigned long long id;
    int flag1=0;

if((fp_dataset=fopen(dataset,"r"))==NULL)
    {
	printf("\nCannot open file %s in hypergraph gen\n",dataset);
	exit(1);
    }
    hname=(char *)calloc(1,20);
    while(fscanf(fp_dataset,"%s",hname)!=EOF)
    {
        uname=(char *)calloc(1,URL_LENGTH);
        fscanf(fp_dataset,"%s",uname);
        fscanf(fp_dataset,"%llu",&id);
        if(!flag1)
        {
            root_dataset=add_node(uname,hname,id);
            current_dataset=root_dataset;
            flag1=1;
        }
        else
        {
            current_dataset->link=add_node(uname,hname,id);
            current_dataset=current_dataset->link;
        }
    }
    fclose(fp_dataset);
}

struct dataset_file *add_node(char *hname,char *uname,unsigned long long id)
{
    struct dataset_file *temp;
    temp=(struct dataset_file*)calloc(1,sizeof(struct dataset_file));
    temp->html_name=(char *)calloc(1,20);
    strcpy(temp->html_name,hname);

     temp->url_name=(char *)calloc(1,URL_LENGTH);
     strcpy(temp->url_name,uname);

     temp->uid=id;
     temp->link=NULL;
     return temp;
}

void hypergraph_gen()
{
    FILE *fp_head;
    unsigned long long id;
    char *h_no;

    h_no=(char *)calloc(1,10);
    if((fp_head=fopen("head.txt","r"))==NULL)
    {
	printf("\nCannot open file %s in hypergraph gen\n",fp_head);
	exit(1);
    }
    if(!feof(fp_head))
    {
        fscanf(fp_head,"%s",h_no);
        root_head=add_head(h_no);
        current_head=root_head;
    }
    while(!feof(fp_head))
    {
        fscanf(fp_head,"%s",h_no);
        current_head->next_head=add_head(h_no);
        current_head=current_head->next_head;
    }
    fclose(fp_head);
    return;
}

struct head *add_head(char *uid)
{
    struct head *temp;
    int j;
    unsigned short *bitvec;
    bitvec=(unsigned short *)calloc(1,(B_VEC_SIZE/8));
     for(j=0;j<(B_VEC_SIZE/16);j++)
    		bitvec[j]=0;
    temp=(struct head *)calloc(1,sizeof(struct head));
    temp->uid=(unsigned long long)atoll(uid);
    temp->bit_vector=gen_bitvector(uid,bitvec);
    for(j=0;j<(B_VEC_SIZE/16);j++)
        bitvec[j]=temp->bit_vector[j];
    temp->childs_list=gen_childs(uid,bitvec);
    temp->next_head=NULL;
    return temp;
}

unsigned short *gen_bitvector(char* temp_uid, unsigned short *hd_bitvec)
{
    unsigned short *bitvec;
    unsigned long long id;
    char out_fname[20];
    int flag=0,j;
    FILE *fp;
    bitvec=(unsigned short *)calloc(1,(B_VEC_SIZE/8));

   for(j=0;j<5;j++)
    		bitvec[j]=0;
     strcpy(out_fname,"out");
    strcat(out_fname,temp_uid);
    strcat(out_fname,".txt");
    if((fp=fopen(out_fname,"r"))==NULL)
    {
	printf("\nCannot open file %s in hypergraph gen\n",out_fname);
	exit(1);
    }
     flag=0;

    for(j=0;j<(B_VEC_SIZE/16);j++)
    {
       if(hd_bitvec[j]!=0)
       {
           flag=1;
           break;
       }
    }
    if(flag)
    {
         for(j=0;j<(B_VEC_SIZE/16);j++)
         {
             bitvec[j]=hd_bitvec[j];
         }
    }
    while(fscanf(fp,"%llu",&id)!=EOF)
    {
        set_bit(id,bitvec);
    }
    return bitvec;
    fclose(fp);
}

void set_bit(unsigned long long id,unsigned short *bit_vector)
{
    unsigned short temp;
    unsigned long long temp_id;
    int i=0,range=16;
    temp=32768;
    temp_id=id%16;
    if(temp_id!=0)
        temp=temp>>(unsigned)(temp_id-1);
    else
        temp=temp>>15;
    while(range<B_VEC_SIZE)
    {
        if(id<=range)
        {
            bit_vector[i]=bit_vector[i]^temp;
           // printf("\nbit vector is:%hx",bit_vector[i]);
            break;
        }
        i++;
        range+=16;
    }

    return ;
}

struct childs *gen_childs(char *head_id, unsigned short *hd_bitvec)
{
    FILE *fp_child;
    char *child_name,*child_id;;
    struct childs *root_child,*current_child;
    child_name=(char *)calloc(1,20);
    child_id=(char *)calloc(1,20);

    strcpy(child_name,"member_");
    strcat(child_name,head_id);
    printf("\nfile nmae is:%s",child_name);

    root_child=NULL;                    //intiate it to NULL, wn there's no child it'll return NULL

    if((fp_child=fopen(child_name,"r"))==NULL)
    {
	printf("\nCannot open file %s in hypergraph gen\n",child_name);
	exit(1);
    }
    if(fscanf(fp_child,"%s",child_id)!=EOF)
    {

        root_child=add_child(child_id,hd_bitvec);
        current_child=root_child;
    }
    while(fscanf(fp_child,"%s",child_id)!=EOF)
    {
        current_child->next_child=add_child(child_id,hd_bitvec);
        current_child=current_child->next_child;
    }
    /*if(fclose(fp_chil+d)!=0)
    {
        printf("\nfile not cloced properly");
    }*/
    return root_child;
}

struct childs *add_child(char *child_id, unsigned short *hd_bitvec)
{
    struct childs *temp;
    temp=(struct childs *)calloc(1,sizeof(struct childs));
    temp->masked_bit_vector=gen_bitvector(child_id,hd_bitvec);
    temp->encoded_bit_vector=(unsigned short *)calloc(1,(B_VEC_SIZE/8));
    temp->next_child=NULL;
    return temp;
}
void display_heads()
{
    struct head *temp;
    struct childs *temp_child;
    int i=0,j=0;
    temp=root_head;
    while(temp!=NULL)
    {
        i=0;
        printf("\nuid is:%llu",temp->uid);
        while(i<(B_VEC_SIZE/16))
        {
            printf("\n\tbit vector[%d] is:%hu",i,temp->bit_vector[i]);
            i++;
        }
        printf("\n");
        temp_child=temp->childs_list;
        printf("\nfirst child\n");
        while(temp_child!=NULL)
        {
            j=0;

            while(j<(B_VEC_SIZE/16))
            {
              printf("\tmasked bit vector[%d] of child is:%hu\t%hu\n",j,temp_child->masked_bit_vector[j],temp_child->encoded_bit_vector[j]);
              j++;
            }
           
            printf("\nnext child\n");
            temp_child=temp_child->next_child;
        }
        temp=temp->next_head;
    }
}

void start_encoding()           //fn starts encoding childs for run-length encoding
{
    struct head *temp;
    struct childs *temp_child;
    temp=root_head;
          
    while(temp!=NULL)       // encode all childs
    {
        temp_child=temp->childs_list;
        mbn=3;              //mega bit no   -   overall count of bit no for RLE
        run_length_encoded_bitvector(temp_child);
/*
        while(temp_child!=NULL)
        {
            mbn=3;
            temp_child=temp_child->next_child;
            run_length_encoded_bitvector(temp_child);
        }
*/
        temp=temp->next_head;
    }
}
void run_length_encoded_bitvector(struct childs *ch)
{
//    struct head *rt;
    struct childs *temp_child;
    int i,j;
    unsigned short tog_bit,cmp;
//    rt=root_head;
/*
    while(rt!=NULL)
    {
        for(i=0;i<(B_VEC_SIZE/16);i++)
        {
            cmp=32768;
            for(j=0;j<16;j++)
            {
                tog_bit=rt->bit_vector[i]&cmp;
                compare_wit_prev_bit(tog_bit,ch);
                cmp=cmp<<1;
            }
        }
        temp_child=rt->childs_list;
*/
    temp_child=ch;
        while(temp_child!=NULL)
        {
            for(i=0;i<(B_VEC_SIZE/16);i++)      //take each elt of bit_vec
            {
                cmp=32768;                      //cmp is 100000000000000
                for(j=0;j<16;j++)               // takes each bit of bit_vec[i]
                {
                    tog_bit=temp_child->masked_bit_vector[i]&cmp;       //tog_bit - has some value if equivalent bit is set in masked_bit_vec
                    if(tog_bit)
                    {
                        tog_bit=1;
                    }
                    compare_wit_prev_bit(tog_bit,ch);
                    cmp=cmp>>1;
                }

            }
            temp_child=temp_child->next_child;
            mbn=3;
        }
   }

//}
compare_wit_prev_bit(unsigned short temp,struct childs *ch)     //compares wit prev bit
{
    static unsigned short cnt=0;
    if(temp==prev_bit)                  //prev_bit set initially(global) as 0
    {
        cnt++;
    }
    else
    {

        if(cnt)                 //first time if a mis match occours cnt will be 0 and function encode will be called unnecessarily
        {
            encode(prev_bit,cnt,ch);
        }
        mbn+=3;
        prev_bit=temp;
        cnt=1;
    }
}

encode(unsigned short p_bit,unsigned short cnt,struct childs *ch)
{
    unsigned short mask=32768,set;
    first_one(cnt,ch);
    if(p_bit)
    {
        set=mask>>(mbn%16);
        ch->encoded_bit_vector[(mbn/16)]|=set;
    }
    mbn++;
}

first_one(unsigned short no,struct childs *ch)              //find the 1st occurence of 1
{
    unsigned short bit_no=0,mask=32768,set,temp_no_of_bits=0;
     while(bit_no<16)
    {
        if(no&(mask>>bit_no))       //identify 1st one
        {
            if(cnt_flag)            //cnt_flag=1 wn its going to set next 7 bits
            {
//                mbn=mbn+no_of_bits;
                cnt_flag=0;          //to run tis loop oly once again,to set 1st 3 bits
                no_of_bits=0;       // to restart d cnt
//                temp_no_of_bits=0;
            }
            else                    //cnt_flag=0 wn its going to set first 3 bits
            {
                mbn=mbn-no_of_bits-3;
                cnt_flag=1;         // to stop recursion
//                temp_no_of_bits=no_of_bits;
            }


            while(bit_no<16)
            {
                if(no&(mask>>bit_no))
                {
                    set=mask>>(mbn%16);
                    ch->encoded_bit_vector[(mbn/16)]|=set;
                }
                if(cnt_flag==0)
                   no_of_bits++;
                mbn++;
                bit_no++;
            }
            if(cnt_flag)
                mbn=mbn+no_of_bits;
            break;
        }
        bit_no++;
    }
    if(cnt_flag==0)
        first_one(no_of_bits,ch);
}