Name		:Sathish Srinivasan
USC id		:2777060734
USC login	:sathishs

To compile the project:(Please make sure the jva version is 1.6)
	javac PropositionalLogic.java

To run the program:

Note: *	Before running please make sure to place all the input files in the current working directory.
	  * The output files are also generated in the same working directory.
		
	java PropositionalLogic -task1 kb1.txt output.txt
	java PropositionalLogic -task2 kb1.txt output.txt
	java PropositionalLogic -task3 kb1.txt statements1.txt output.txt

Status:


*The prorgam run as expected and desired output is obtained.
*It terminates if the resolving takes more than 5 mins.