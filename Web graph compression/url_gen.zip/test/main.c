
#include<stdio.h>
#include<stdlib.h>       //included to use random function
#include<string.h>
#define URL_LENGTH 200
#define MAX_NO_OF_DIGITS 5
#define dataset "url.txt"

/******
struct node :: the structure of nodes in d list tat maintains(web sites)
******/

struct node
{
int data;
char *url;
struct node *link;
struct out_links *list_of_outgoinglinks;
}*root,*curr_node,*next_node;


//FILE *fp,*fpt,*dt,*chk;

/******
struct out_links :: the structure of nodes in d list tat maintains all out-going links from a site
******/

struct out_links
{
	struct node *points_to;
	struct out_links *next_node;
}*outlink;

/**********
function prototype declaration
**********/

struct node *create_node(char *);
int graph_gen();
struct node *find_node_addr(char *);
struct out_links *create_outlink_node(char *);
int check(int,int,int *,int *);
void outlink_gen(struct node *);
char *find_filenm(char *);
int crc1(char *);
/**************
fun 	: create a new node
param   : nil
return	: address of new_node
***************/

struct node *create_node(char *temp1)
{
	struct node *new_node;
	new_node=(struct node *)malloc(sizeof(struct node));    //alloc memory
	new_node->data=crc1(temp1);
	new_node->url=(char *)malloc(URL_LENGTH);
	strcpy(new_node->url,temp1);
	new_node->link=NULL;
	new_node->list_of_outgoinglinks=NULL;
	return new_node;
}
/**************
fun 	: generates d graph
param   : total no of nodes
return	: NIL
***************/

int graph_gen()
{
	int graph_size=0;
	FILE *fp;
	char *temp;
	temp=(char *)malloc(URL_LENGTH);
	fp=fopen(dataset,"r");
	fscanf(fp,"%s",temp);		//written twice because we have 2 read the 2nd word
	fscanf(fp,"%s",temp);
	root=create_node(temp);
	curr_node=root;
	while(fscanf(fp,"%s",temp)!=EOF)		//list generation
	{
		fscanf(fp,"%s",temp);
		next_node=create_node(temp);
		curr_node->link=next_node;
		curr_node=next_node;
	}                              //while end
/*
//	free(temp);

	curr_node=root;
	printf("%d--> ",curr_node->data);
	printf(" %s\n",curr_node->url);
	graph_size++;
	do
	{
		curr_node=curr_node->link;
		printf("%d--> ",curr_node->data);
		printf(" %s\n",curr_node->url);
		graph_size++;
	}while(curr_node->link!=NULL);		//do-while end
*/
	fclose(fp);
	return(graph_size);
}

int crc1(char *temp)
{
   static int node_no=0;
   return(node_no++);
}

			//outlink generation//
/**************
fun 	: finds the node to be pointed
param   : var-data node to be pointed
return	: req nodes address
***************/

struct node *find_node_addr(char *var)
{
	struct node *present_node;
	present_node=root;
	do
	{
		if(strcmp(present_node->url,var)==0)
		{
		break;
		}
		present_node=present_node->link;
	}while(present_node->link!=NULL);
	return present_node;
}

/**************
fun 	: create a new node
param   : nil
return	: address of new_node
***************/

struct out_links *create_outlink_node(char *temp_node_content)
{
	struct out_links *temp;
	temp=(struct out_links *)malloc(sizeof(struct out_links));
	temp->points_to=find_node_addr(temp_node_content);
//	printf("(%d,%s)\n",temp->points_to->data,temp_node_content);
	temp->next_node=NULL;
	free(temp_node_content);
	return temp;

}

/**************
fun 	: generates d outlinks for node passed
param   : total no of nodes,node for which outlinks needed to be generated
return	: NIL
***************/

void outlink_gen(struct node *temp_curr_node)
{
	struct out_links *outlink_header,*curr_outlink_node,*next_outlink_node;
	int i,no_of_outlinks,node_content,temp_var1;	//node_content : has data of the node to be pointed ; outlinks_array : has values of nodes to be pointed & temp_array is used for manipulation of outlinks_array
	char *out_url,*out_file;
	FILE *out_fp;
	out_file=find_filenm(temp_curr_node->url);

	//////////////////////////////
	if((out_fp=fopen(out_file,"r"))==NULL)
	{
		printf("Cannot open file %s in full graph\n",out_file);
		exit(1);
	}
	if(!feof(out_fp))
	{
		out_url=(char *)calloc(1,URL_LENGTH);
		fscanf(out_fp,"%s",out_url);
		outlink_header=create_outlink_node(out_url);
		curr_outlink_node=outlink_header;
	}
	else
	  outlink_header=NULL;  //the node has no outlink, outlink is assinged to NULL
	while(!feof(out_fp))	//gen link list of outlinks
	{
		out_url=(char *)calloc(1,URL_LENGTH);
		fscanf(out_fp,"%s",out_url);
		next_outlink_node=create_outlink_node(out_url);
		curr_outlink_node->next_node=next_outlink_node;
		curr_outlink_node=next_outlink_node;
	}
	temp_curr_node->list_of_outgoinglinks=outlink_header;
	fclose(out_fp);
}

char* outlinks(char *file)
{
	char *str1,*fil_num,ext[5]=".txt\0",*file_nm,*temp,*temp1;
	int i=0,flag;
	FILE *fp,*fpt,*dt,*chk;
	static int file_no=0;

	file_nm=(char *)calloc(1,7+MAX_NO_OF_DIGITS);
	fil_num=(char *)calloc(1,MAX_NO_OF_DIGITS);
	file_no++;
	strcpy(file_nm,"out");
	sprintf(fil_num,"%d",file_no);

//	itoa(file_no,fil_num,10);
	strcat(file_nm,fil_num);
	strcat(file_nm,ext);
	printf("%s",file_nm);
	if ((fpt = fopen(file_nm,"w"))==NULL)		//if there exists a file of tis name it clears its data
	{
		printf("Cannot open file %s in outlinks-1\n",file_nm);
		exit(1);
	}
	fclose(fpt);

	if ((fp = fopen(file,"r"))==NULL)
	{
		printf("Cannot open file %s in outlinks-2\n",file);
		exit(1);
	}
	str1=(char *)calloc(1,URL_LENGTH);
	temp=(char *)calloc(1,URL_LENGTH);
	while(fscanf(fp, "%s", str1)!=EOF)
	{

		if((temp1=strstr(str1,"href=\"http:"))!=NULL)
		{
			while(str1[i+6]!='"')
			{
				temp[i]=temp1[i+6];
				i++;
			}
			temp[i]='\0';
			flag=is_in_dataset(temp);
	  		if(flag==1)	//0-not in dataset & 1-is in dataset
			{
			      	if(is_repeating(file_nm,temp))	//1-not a repeatin url & 0-repeating url
				{
					if((fpt=fopen(file_nm,"a"))==NULL)
					{
						printf("Cannot open file %s in outlinks-3\n",file_nm);
						exit(1);
					}
					fprintf(fpt,"%s\n",temp);
					fclose(fpt);
	//				printf("%s\n",temp);
				}
			}
			i=0;
		}
		//free(temp);
		//free(str1);
		//str1=(char *)calloc(1,URL_LENGTH);
	}
	fclose(fp);
	free(fil_num);
	//free(str1);
	return(file_nm);
}
int is_in_dataset(char *temp_url)
{
	int flag2=1;
	char *temp,*str;
	FILE *fp,*fpt,*dt,*chk;
	str=(char *)malloc(URL_LENGTH);
	if((dt=fopen(dataset,"r"))==NULL)
	{
		perror("");
		printf("Cannot open file url.txt in outlinks-4\n");
		exit(1);
	}
	while(flag2)
	{
		if(fscanf(dt,"%s",str)!=EOF)
		{
			if(strcmp(str,temp_url)==0)
				flag2=0;
		}
		else
			break;
	}
	fclose(dt);
	return(!flag2);
}

int is_repeating(char *fil,char *temp_url)
{
	int flag1=1;
	FILE *fp,*fpt,*dt,*chk;
	char *str;
	str=(char *)malloc(URL_LENGTH);
	if((chk=fopen(fil,"r"))==NULL)
	{
		perror("perror : ");
		printf("Cannot open file %s in outlinks-5\n",fil);
		exit(1);
	}
	while(flag1)
	{
		if(fscanf(chk,"%s",str)!=EOF)
		{
			if(strcmp(str,temp_url)==0)
			{
				flag1=0;
				break;
			}
		}
		else
			break;
	}
	fclose(chk);
	return(flag1);
}
char *find_filenm(char *uid)
{
	char str[URL_LENGTH],*temp;
	char *result;
	FILE *url;
	temp=(char *)calloc(1,URL_LENGTH);
	if ((url=fopen(dataset,"r"))==NULL)
	{
		printf("Cannot open file dataset find_fil-1\n");
		exit(1);
	}
	while(fscanf(url,"%s",str)!=EOF)
	{
		if(strcmp(str,uid)==0)
			break;
		strcpy(temp,str);
	}
	fclose(url);
//	free(str);
	result=outlinks(temp);
	free(temp);
	return result;

}
int main()
{
	FILE *ptr;
	struct node *traversal_node;
	int temp_size;
	temp_size=graph_gen();
	traversal_node=root;
	while(traversal_node->link!=NULL)
	{
		outlink_gen(traversal_node);
		traversal_node=traversal_node->link;
	}
	outlink_gen(traversal_node);
	return 0;

}
