-----------------------------------------------------------------------------------------------------------------------------------------------------------------

Team Members:
-------------

Sasitharan Jayagopal
Vinodh Sankaravadivel
Karthik Ramasamy
Sathish Srinivasan

Equal share split
------------------

Note:	*Currently the DRIVERS, VFS, S5FS and VM is set to 1 in config.mk
	*The assignment is only partially done.

Completed coding:
-----------------
pframe functions
vmmap functions
anon functions
shadow functions
pagefault


KASSERTS corresponding to above functions are added and are printed by dbg statements .

We have written 2 testcases which has valid dbg statements. They can be read by using 'grep TESTCASE3'. 

1.)Initially test1 runs which executes SEGFAULT program. This completes fine!!
2.)Kshell is then opened where "vfstest" can be run with command "vfstest". This completes fine !!
Weenix halts cleanly then !!

tests completed:
		506 passed
		0 failed

Please do not run any other tests! They do not work !!
