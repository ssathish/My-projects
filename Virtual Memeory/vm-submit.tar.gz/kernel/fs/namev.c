#include "kernel.h"
#include "globals.h"
#include "types.h"
#include "errno.h"

#include "util/string.h"
#include "util/printf.h"
#include "util/debug.h"

#include "fs/dirent.h"
#include "fs/fcntl.h"
#include "fs/stat.h"
#include "fs/vfs.h"
#include "fs/vnode.h"

#include "mm/kmalloc.h"

/* This takes a base 'dir', a 'name', its 'len', and a result vnode.
 * Most of the work should be done by the vnode's implementation
 * specific lookup() function, but you may want to special case
 * "." and/or ".." here depnding on your implementation.
 *
 * If dir has no lookup(), return -ENOTDIR.
 *
 * Note: returns with the vnode refcount on *result incremented.
 */
int
lookup(vnode_t *dir, const char *name, size_t len, vnode_t **result)
{
        KASSERT(NULL != dir);
        
        KASSERT(NULL != name);
        
        KASSERT(NULL != result);
        
        int return_code;
        
        if(!dir->vn_ops->lookup)
        {
			return -ENOTDIR;
		}
		
		if(len == 0)
		{
			vget(dir->vn_fs, dir->vn_vno);
			return 0;
		}	
        
        return_code = dir->vn_ops->lookup(dir, name, len, result);
        return return_code;
}

/* When successful this function returns data in the following "out"-arguments:
 *  o res_vnode: the vnode of the parent directory of "name"
 *  o name: the `basename' (the element of the pathname)
 *  o namelen: the length of the basename
 *
 * For example: dir_namev("/s5fs/bin/ls", &namelen, &name, NULL,
 * &res_vnode) would put 2 in namelen, "ls" in name, and a pointer to the
 * vnode corresponding to "/s5fs/bin" in res_vnode.
 *
 * The "base" argument defines where we start resolving the path from:
 * A base value of NULL means to use the process's current working directory,
 * curproc->p_cwd.  If pathname[0] == '/', ignore base and start with
 * vfs_root_vn.  dir_namev() should call lookup() to take care of resolving each
 * piece of the pathname.
 *
 * Note: A successful call to this causes vnode refcount on *res_vnode to
 * be incremented.
 */
int
dir_namev(const char *pathname, size_t *namelen, const char **name,
          vnode_t *base, vnode_t **res_vnode)
{
	KASSERT(NULL != pathname);

	KASSERT(NULL != namelen);

	KASSERT(NULL != name);

	KASSERT(NULL != res_vnode);

	int i = 0, iterate_again = 1, flag = 0;
	size_t char_index = 0;
	vnode_t *root_dir;
	int return_code;
	char *temp_name = kmalloc(NAME_LEN);

	if(base == NULL)
		root_dir = curproc->p_cwd;

	if(pathname[0] == '/')
		root_dir = vfs_root_vn;

	
	char *modified_path=(char *)kmalloc(strlen(pathname));

	strcpy(modified_path,pathname);
	for(i=strlen(modified_path)-1;;)
	{
		if (modified_path[i]== '/')
		{
			modified_path[i]='\0';
			i=strlen(modified_path)-1;
		}
		else
			break;
	}
	
	i=0;
	while (iterate_again)
	{
		for(; i < (int) strlen(modified_path); i++)
		{
			if(i == (int)(i+char_index) && modified_path[i] == '/')
			{
				continue;
			}

			else if(i != (int)(i+char_index) && modified_path[i] == '/')
			{
				temp_name[char_index] = '\0';

				if(char_index > NAME_LEN)
				{
					return -ENAMETOOLONG;
				}

				return_code = lookup(root_dir, temp_name, char_index, &root_dir);

				if(return_code < 0)
					return return_code;

				if(!S_ISDIR((root_dir)->vn_mode))
				{
					vput(root_dir);
					return -ENOTDIR;
				}
				if(((strcmp(temp_name, "usr")) != 0) && ((strcmp(temp_name, "bin")) != 0))
					vput(root_dir);
				if((i+1) == (int)strlen(modified_path))
				{
					*name = "";
					*namelen = 0;
					*res_vnode = vget(root_dir->vn_fs, root_dir->vn_vno);
					flag = 1;
				}

				break;
			}

			else
			{
				temp_name[char_index] = modified_path[i];
				char_index++;
			}
		}

		if(i >= (int) strlen(modified_path))
		{
			if(flag)
				return 0;

			temp_name[char_index] = '\0';

			if(char_index > NAME_LEN)
			{
				return -ENAMETOOLONG;
			}

			*name = temp_name;
			*namelen = char_index;
			*res_vnode = vget(root_dir->vn_fs, root_dir->vn_vno);
			KASSERT(NULL != *res_vnode);

			return 0;
		}
		char_index = 0;
	}

	return 0;
}

/* This returns in res_vnode the vnode requested by the other parameters.
 * It makes use of dir_namev and lookup to find the specified vnode (if it
 * exists).  flag is right out of the parameters to open(2); see
 * <weenix/fnctl.h>.  If the O_CREAT flag is specified, and the file does
 * not exist call create() in the parent directory vnode.
 *
 * Note: Increments vnode refcount on *res_vnode.
 */
int
open_namev(const char *pathname, int flag, vnode_t **res_vnode, vnode_t *base)
{
        int return_code;
        size_t file_vnode_len;
        const char *file_vnode_name;
        
        return_code = dir_namev(pathname, &file_vnode_len, &file_vnode_name, base, res_vnode);
        if(return_code < 0)
			return return_code;
		vput(*res_vnode);	
			
		return_code = lookup(*res_vnode, file_vnode_name, file_vnode_len, res_vnode);
		if(return_code == -ENOENT && ((flag & O_CREAT) == O_CREAT))
		{
            KASSERT(NULL != (*res_vnode)->vn_ops->create);
			int return_code = (*res_vnode)->vn_ops->create(*res_vnode, file_vnode_name, file_vnode_len, res_vnode);
			return return_code;
		}
        return return_code;
}

#ifdef __GETCWD__
/* Finds the name of 'entry' in the directory 'dir'. The name is writen
 * to the given buffer. On success 0 is returned. If 'dir' does not
 * contain 'entry' then -ENOENT is returned. If the given buffer cannot
 * hold the result then it is filled with as many characters as possible
 * and a null terminator, -ERANGE is returned.
 *
 * Files can be uniquely identified within a file system by their
 * inode numbers. */
int
lookup_name(vnode_t *dir, vnode_t *entry, char *buf, size_t size)
{
        NOT_YET_IMPLEMENTED("GETCWD: lookup_name");
        return -ENOENT;
}


/* Used to find the absolute path of the directory 'dir'. Since
 * directories cannot have more than one link there is always
 * a unique solution. The path is writen to the given buffer.
 * On success 0 is returned. On error this function returns a
 * negative error code. See the man page for getcwd(3) for
 * possible errors. Even if an error code is returned the buffer
 * will be filled with a valid string which has some partial
 * information about the wanted path. */
ssize_t
lookup_dirpath(vnode_t *dir, char *buf, size_t osize)
{
        NOT_YET_IMPLEMENTED("GETCWD: lookup_dirpath");

        return -ENOENT;
}
#endif /* __GETCWD__ */
