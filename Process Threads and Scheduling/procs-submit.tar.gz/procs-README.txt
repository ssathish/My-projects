
-----------------------------------------------------------------------------------------------------------------------------------------------------------------

Team Members:
-------------

Sasitharan Jayagopal
Vinodh Sankaravadivel
Karthik Ramasamy
Sathish Srinivasan

Equal share split
------------------

Note:Currently the DRIVERS is set to 1 in config.mk

DBG statements:
--------------

When executed normally( not from kshell)
1.)dbg statements for the expected KASSERTS are preceeded by "GRADING x.y"
2.)dbg statements for the testcases are prceeded by "TESTCASE -"
will be printed on terminal

When executed from kshell
1.)dbg statements for the testcases are prceeded by "TESTCASE -"
will be printed on terminal

Bootstrap, Idle and Init process
--------------------------------
Idle process is first created. followed by creation of a thread for idle process.(First thread context)
Init Process is created as a child process as a Idle process . A thread for the init pocess is then created which is the parent of all process and runs as long as OS is shutdown.

1.)bootstrap
2.)initproc_create
3.)initproc_run

Testcase1: Create a bunch of processes with one thread for each process and terminate them gracefully.
------------------------------------------------------------------------------------------------------

Description:
------------
*Init process creates five child processes (P1,P2,P3,P4 and P5) (in proc_create)
*Everytime a process is created one thread is also created for it (in kthread_create)
*The thread created is then made runnable (sched_make_runnable);
*This way at the end when five processes are created there are five threads waiting in runqueue while thread of init process is currently running.
*Init process then waits for child process to die (in do_waitpid ) and goes to sleep (in sched_sleep_on -> sched_switch -> context switches to P1 next in runqueue).
*P1 runs up to completion. 
*After P1 ends kthread_exit is called which sets the return value in TCB,makes the thread state to KT_EXITED and intimates the process that the thread is dead by calling proc_thread_exited.
*proc_thread_exited then performs cleanup (proc_cleanup) where it sets up the return value in PCB, changes state to PROC_DEAD, wakes up(sched_wakeup_on) the parent process (here init process) waiting for the child process to die.
*sched_wakeup_on makes init process runnable (sched_make_runnable) by appending it to end of runqueue.
*on return to proc_thread_exited it calls sched_switch which switches context and makes P2 to run.
*Each process P2,P3,P4 and P5 performs the above steps 6-10 and all gets terminated.
*After P5 th context switches to init process which is waiting on do_waitpid . It sees that all the child process are dead anc performs final cleanup on the child processes where the PCB's are removed.

Functions used:
---------------
1.)proc_create
2.)kthread_create
3.)sched_make_runnable
4.)do_waitpid
5.)sched_sleep_on
6.)sched_switch
7.)kthread_exit
8.)proc_thread_exited
9.)proc_cleanup
10.)sched_wakeup_on

Testcase2: Demonstrate how synchronization primitives work
----------------------------------------------------------

Description:
------------
*Init process creates three child processes (P1,P2 and P3) then calls sched_make_runnable and sched_switch and explicitly gives control to the next pocess in runqueue (P1 in this case)
*First process(P1) lock mutex m1(in kmutex_lock) and goes to sleep  (sched_sleep_on -> sched_switch -> context switches to second process) 
*Second process(P2) tries to lock mutex m1 and gets added to the queue of m1 and goes to sleep.(same as above but context now switches to third process)
*Third process(P3) tries to lock mutex m1 and is added to the queue of m1 and goes to sleep.(same as above but context now switches to init process).
*Init process then wakes up P1 and waits for the child process to die (in do_waitpid).
*First process then unlocks mutex m1 and second process(P2) waiting in the mutex queue now gets m1(in kmutex_unlock)which makes P2 runnable and gets appended to run queue.
*First process then terminates which makes init to wakeup(in do_waitpid) and init gets appended to run queue.
*Second process then goes to sleep and switches the context to init (in sched_sleep_on -> sched_switch -> context_switch).
*Init process then wakes up P2 and waits for the child process to die (in do_waitpid).
*Second process then unlocks mutex m1 and third process(P3) waiting in the mutex queue now gets m1(in kmutex_unlock)which makes P3 runnable and gets appended to run queue.
*Second process then terminates which makes init to wakeup(in do_waitpid) and init gets appended to run queue.
*Third process then goes to sleep and switches the context to init (in sched_sleep_on -> sched_switch -> context_switch).
*Init process then wakes up P3 and waits for the child process to die (in do_waitpid).
*Third process then unlocks mutex m1 and terminates which makes init to wakeup(in do_waitpid).
*Init then performs final cleanup on terminated processes.
*End of Testcase2

Functions tested in this testcase:
----------------------------------
Additional functions tested apart from the previous test cases
1.)kmutex_init
2.)kmutex_lock
3.)kmutex_unlock

Testcase3: Create circular wait and cause deadlock scenario (When deadlock occurs OS hangs for few seconds; kindly wait for the execution to continue by itself)
-----------------------------------------------------------

Description:
------------
*Init process creates two child processes (P1 and P2) and then calls sched_make_runnable and sched_switch and explicitly gives control to the next pocess in runqueue (P1 in this case)
*P1 locks mutex m1(in kmutex_lock) and goes to sleep (sched_sleep_on -> sched_switch -> context switches to second process).
*P2 locks mutex m2(in kmutex_lock),wakes up P1(sched_wakeup_on) then tries to lock m1 (in kmutex_lock_cancellable) but it is already locked by P1. So it adds itself to the mutex wait queue of m1 and goes to sleep.(sched_cancellable_sleep_on -> sched_switch -> context switches to init process).
*Init process then calls sched_make_runnable and sched_switch and explicitly gives control to the next pocess in runqueue (P1 in this case). (Note control is gien explicitly because after deadlock init need to call proc_kill to terminate the deadlocked processes. This cannot be done if it is made to wait in do_waitpid).
*P1 now tries to lock m2(kmutex_lock_cancellable) but it is already locked by P2. So it adds itself to the mutex wait queue of m2 and goes to sleep. (sched_cancellable_sleep_on -> sched_switch -> context switches to init process )
*Deadlock occurs!!!!!! 
*After few seconds init process calls proc_kill on the two deadlocked processes.(proc_kill -> kthread_cancel -> sched_cancel ->sched_make_runnable). 
*kthread_cancel sets the cancelled flag in the corresponding thread anc calls sched_cancel. Since the deadlocked processes are in cancellable sleep,it is dequeued from the corresponding mutex wait queue and becomes runnable.
*Init then calls do_waitpid and waits for the deadlocked processes to terminate and goes to sleep. 
*When the deadlocked processes stats running , it finds itself returned from sleep with EINTR . This makes the threads to enter cancellation routine where  the mutexes already locked are unlocked and terminates itself which cause init to wakeup from do_waitpid.
*Init then performs final cleanup on terminated processes.
*End of Testcase3


Functions tested in this testcase:
----------------------------------
Additional functions tested apart from the previous test cases
1.)kmutex_lock_cancellable
2.)sched_cancellable_sleep_on
3.)proc_kill
4.)kthread_cancel
5.)sched_cancel

Testcase:4 Reparenting child process of current terminated process  to init process.
------------------------------------------------------------------------------------

Description:
------------
*Init process creates a child process (P1) which in turn creates two child process (P2 and P3).
*Process P1 (current process) immediately terminates by calling do_exit.
*When P1 terminates it calls kthread_exit which calls proc_thread_exited which in turn calls proc_cleanup.
*When P1 is cleaned up it makes init process as parent for its children P2 and P3.
*It also wakes up the init process waiting in do_waitpid for P1 to be dead.
*Init process then performs the final cleanup freeing the PCB for P1.
*Please note that the child process P2 and P3 are not cleaned up as init is not on do_waitpid for these processes.
*But they are cleaned up finally before the init process terminates.

Functions tested in this testcase:
----------------------------------
Additional functions tested apart from the previous test cases
1.)do_exit



Testcase 5: Demonstration of Solution to Barrier process.
-----------------------------------------------------------

In this testcase 5 processes are created and one by one enters a barrier (a function). Only when the last process (the fifth process, P5) enters the barrier all the other process are provided a signal to continue executing. Unitl then the remaining four processes just waits for the fifth to enter the barrier and signal them.

*The Init process creates five (say,p1 to p5) processes, a single thread for each process, makes it runnable, initializes a single mutex m1 and a conditional wait queue. It then calls do_waitpid() and goes to sleep until its child processes terminates. The context switches to the first process, P1.
*P1 locks mutex m1, finds itself to be the first process entering the barrier and goes to sleep in a conditional wait queue (by unlocking the mutex m1). A count variable is incremented. The context switches to the second process, P2.
*P2 locks mutex m1, finds itself to be the second process entering the barrier and goes to sleep in the same conditional wait queue (by unlocking the mutex m1). The count variable is incremented. The context switches to the third process, P3.
*P3 locks mutex m1, finds itself to be the third process entering the barrier and goes to sleep in the same conditional wait queue (by unlocking the mutex m1). The count variable is incremented. The context switches to the fourth process, P4.
*P4 locks mutex m1, finds itself to be the fourth process entering the barrier and goes to sleep in the same conditional wait queue (by unlocking the mutex m1). The count variable is incremented. The context switches to the fifth process, P5.
*P5 locks mutex m1, finds itself to be the fifth and final process entering the barrier. It resets the count to zero and broadcasts (wakes up all 4 processes sleepin the conditional wait queue) that the required count has been reached. All four processes are made runnable and join runqueue.
*P5 terminates wakes up Init process which performs final cleanup on P5 and goes to sleep waiting for other child processes to terminate. 
*This makes P1 to run. P1 returns from the wait queue by locking the mutex m1, then terminates and wakes up Init process which performs final cleanup on P5 and goes to sleep waiting for other child processes to terminate.
*This continues until traces of all the remaining child process are completely destroyed by INIT process.
*The test case ends.

Additional functions checked apart from functions in previous testcases:
---------------------------------------------------------------------------
sched_broadcast_on();


Testcase 6: Producer Consumer problem.
----------------------------------------

In this testcase a producer and a consumer is created. Producer producers items and places it in a buffer (an array of size 10) at a rate of rate_p(initially 3) if and only if there is an empty space in the buffer. Consumer consumes items from the buffer at a rate rate_c (initially 3) if and only if there is atleast one occupied slot in the buffer. This continues until 25 items are produced and consumed.

*Two semaphores are created, empty and occupied, with initial values 10 and 0. A mutex m1 and a conditional wait queue is also implemented.
*Init process creates two process producer and consumer, a single thread for each process and makes it runnable. Then it calls do_waitpid and first waits for producer to terminate. The context switches to Producer.
*Producer locks mutex m1 and checks if empty is greater than zero. If it is greater than zero then step 1 else step 2.
	1)Producer decrements count, unlocks m1, produce an item and places them in the buffer, again locks m1, increments occupied and unlocks mutex checking everytime if 25 items have been produced. This step continues for 'rate_p' times. It then makes itself runnable and explicitly switches control to consumer process. 
	2)Producer unlocks m1 and enters conditional wait queue, waits there until atleast one empty slot is available (empty > 0).
*Consumer locks m1 and checks if occupied is greater than zero. If it is greater than zero then step 3 else step 4.
	3)Consumer decrements occupied, unlocks m1, Consumes an item, again locks m1, increments empty and unlocks mutex checking everytime if 25 items have been consumed. This step continues for 'rate_p' times. It then makes itself runnable and explicitly switches control to Producer process. 
	4)Consumer unlocks m1 and enters conditional wait queue, waits there until atleast one occupied slot is available (occupied > 0).
	
Please note... 
Everytime a switch from producer to consumer takes place, the value of 'rate_c' is changed. Similarly, a switch from consumer to producer takes place, the value of 'rate_p' is changed.

Everytime producer increments occupied by one, it sends a signal to the conditional wait queue that occupied is greater then zero. If consumer is sleeping in the queue it is made runnable and when switched returns with m1 locked. If consumer is not in the queue, the signal is simply ignored.

Everytime consumer increments empty by one, it sends a signal to the conditional wait queue that empty is greater then zero. If producer is sleeping in the queue it is made runnable and when switched returns with m1 locked. If producer is not in the queue, the signal is simply ignored.

This continues until 25 items are produced by producer and consumed by consumer. In any case producer will be the first process to exit waking up the INIT process and switching context to Consumer process.

The Init process then waits for the consumer to terminate and INIT process performs the final cleanup of both processes. 


*****************************************************************************************************************************************************************

IMPORTANT..PLEASE READ
*****************************************************************************************************************************************************************

Testcase 7: Demonstrate testcases in KSHELL
--------------------------------------------------

*A new process for KSHELL creation and command execution is created from the INIT process. The INIT process waits until this process ends by switching context to Kshell process. 
*When the kshell process starts a Kshell is created and it prompts for commands to be entered by the User. Please follow below instructions to execute the testcases...

The testcases 1-6 can be invoked seperately and correctly by typing in commands

test_1 - for testcase 1
test_2 - for testcase 2
test_3 - for testcase 3 - (When deadlock occurs OS hangs for few seconds; kindly wait for the execution to continue by itself)
test_4 - for testcase 4
test_5 - for testcase 5
test_6 - for testcase 6

When the testcases are executed from KSHELL it runs in a mode such that the dbg statements (starting with "GRADING X.Y") after KASSERT doesnot execute. Only the dbg statements that we have used to explain the flow of testcases will be executed and printed. This we have done so that it will be easy for you to understand the flow easily. 

Please donot forget to call exit after executing all 6 test cases. 

The final TESTCASE which works only after the kshell exits....
 
When exit is called from the kshell the kshell process terminates, waking up the INIT process which doen a final cleanup on the kshell process. Then loops through its children list waking up its step children (orphaned process reparented to INIT during TESTCASE 4) and finally calls a proc_kill_all killing only the step children process (and not the INIT process, as it is not supposed to do so!!!), waits for them to terminate and does the final cleanup.

Additional functions checked apart from functions in previous testcases:
---------------------------------------------------------------------------
proc_kill_all();



This concludes all our testcases implemented to test the correct functioning of the PROCS functions implemeted.

****************************************************************************************************************************************************************
****************************************************************************************************************************************************************
