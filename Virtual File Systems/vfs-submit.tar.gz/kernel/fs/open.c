/*
 *  FILE: open.c
 *  AUTH: mcc | jal
 *  DESC:
 *  DATE: Mon Apr  6 19:27:49 1998
 */

#include "globals.h"
#include "errno.h"
#include "fs/fcntl.h"
#include "util/string.h"
#include "util/printf.h"
#include "fs/vfs.h"
#include "fs/vnode.h"
#include "fs/file.h"
#include "fs/vfs_syscall.h"
#include "fs/open.h"
#include "fs/stat.h"
#include "util/debug.h"
#include "fs/lseek.h"

#define ACCESSMODE 0x0FF
#define STATUSFLAG 0x700

void print_err_message(char *func_name, int err);

/* find empty index in p->p_files[] */
int
get_empty_fd(proc_t *p)
{
        int fd;

        for (fd = 0; fd < NFILES; fd++) {
                if (!p->p_files[fd])
                        return fd;
        }

        dbg(DBG_ERROR | DBG_VFS, "ERROR: get_empty_fd: out of file descriptors "
            "for pid %d\n", curproc->p_pid);
        return -EMFILE;
}

/*
 * There a number of steps to opening a file:
 *      1. Get the next empty file descriptor.
 *      2. Call fget to get a fresh file_t.
 *      3. Save the file_t in curproc's file descriptor table.
 *      4. Set file_t->f_mode to OR of FMODE_(READ|WRITE|APPEND) based on
 *         oflags, which can be O_RDONLY, O_WRONLY or O_RDWR, possibly OR'd with
 *         O_APPEND.
 *      5. Use open_namev() to get the vnode for the file_t.
 *      6. Fill in the fields of the file_t.
 *      7. Return new fd.
 *
 * If anything goes wrong at any point (specifically if the call to open_namev
 * fails), be sure to remove the fd from curproc, fput the file_t and return an
 * error.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EINVAL
 *        oflags is not valid.
 *      o EMFILE
 *        The process already has the maximum number of files open.
 *      o ENOMEM
 *        Insufficient kernel memory was available.
 *      o ENAMETOOLONG
 *        A component of filename was too long.
 *      o ENOENT
 *        O_CREAT is not set and the named file does not exist.  Or, a
 *        directory component in pathname does not exist.
 *      o EISDIR
 *        pathname refers to a directory and the access requested involved
 *        writing (that is, O_WRONLY or O_RDWR is set).
 *      o ENXIO
 *        pathname refers to a device special file and no corresponding device
 *        exists.
 */

int
do_open(const char *filename, int oflags)
{
	if(curproc->p_pid < 9 && curproc->p_pid != 5)
	dbg(DBG_TESTPASS, "TESTCASE2 - do_open called on path %s!!!!\n",filename);
	if(strlen(filename) < 1)
	{
		print_err_message("do_open", EINVAL);
		return -EINVAL;
	}

	if(strlen(filename) > MAXPATHLEN)
	{
		print_err_message("do_open", ENAMETOOLONG);
		return -ENAMETOOLONG;
	}

	int nextempty_fd, return_code;
	file_t *new_file;

	nextempty_fd = get_empty_fd(curproc);			/* get next empty file descriptor*/
	if(nextempty_fd == -EMFILE)
	{
		print_err_message("do_open", EMFILE);
		return -EMFILE;
	}

	new_file = fget(-1);

	if(!new_file)									/* pass -1 as argument to get a new file*/
	{
		print_err_message("do_open", ENOMEM);
		return -ENOMEM;
	}

	/*disintegrating access modes and status flags from the flags field and storing them seperately*/

	int access_modes = oflags & ACCESSMODE;

	if((access_modes != O_RDONLY) && (access_modes != O_WRONLY) && (access_modes != O_RDWR))
	{
		print_err_message("do_open", EINVAL);
		return -EINVAL;
	}

	int append_flag = oflags & O_APPEND;
	int trunc_flag = oflags & O_TRUNC;
	int create_flag = oflags & O_CREAT;

	if (access_modes == O_RDONLY)
		new_file->f_mode = FMODE_READ;
	else if (access_modes == O_WRONLY)
	{
		if ((append_flag == O_APPEND) && (trunc_flag != O_TRUNC))
			new_file->f_mode = FMODE_APPEND;
		else
			new_file->f_mode = FMODE_WRITE;
	}
	else
	{
		if ((append_flag == O_APPEND) && (trunc_flag != O_TRUNC))
			new_file->f_mode = FMODE_READ | FMODE_WRITE | FMODE_APPEND;
		else
			new_file->f_mode = FMODE_READ | FMODE_WRITE;
	}

	return_code = open_namev(filename, oflags, &new_file->f_vnode, NULL);

	if(return_code == -ENOENT || ((return_code == -ENOENT) && ((oflags & O_CREAT) == O_CREAT)))
	{
		new_file->f_refcount = new_file->f_refcount - 1;
		print_err_message("do_open", ENOENT);
		return -ENOENT;
	}

	if(return_code == -ENAMETOOLONG)
	{
		new_file->f_refcount = new_file->f_refcount - 1;
		print_err_message("do_open", ENAMETOOLONG);
		return return_code;
	}

	if(return_code < 0)
	{
		new_file->f_refcount = new_file->f_refcount - 1;
		print_err_message("do_open", (return_code * -1));
		return return_code;
	}

	if((S_ISDIR(new_file->f_vnode->vn_mode)) && (((new_file->f_mode & ACCESSMODE) == FMODE_WRITE) || ((new_file->f_mode & ACCESSMODE) == (FMODE_WRITE|FMODE_READ))))
	{
		fput(new_file);
		print_err_message("do_open", EISDIR);
		return -EISDIR;
	}

	curproc->p_files[nextempty_fd] = new_file;		 /*saving the new file into the curproc's FDT indexed by file descriptor*/

	return nextempty_fd;
}
