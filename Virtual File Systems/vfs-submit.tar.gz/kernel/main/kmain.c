#include "types.h"
#include "globals.h"
#include "kernel.h"

#include "util/gdb.h"
#include "util/init.h"
#include "util/list.h"
#include "util/debug.h"
#include "util/string.h"
#include "util/printf.h"

#include "mm/mm.h"
#include "mm/page.h"
#include "mm/pagetable.h"
#include "mm/pframe.h"
#include "mm/kmalloc.h"

#include "vm/vmmap.h"
#include "vm/shadow.h"
#include "vm/anon.h"

#include "main/acpi.h"
#include "main/apic.h"
#include "main/interrupt.h"
#include "main/cpuid.h"
#include "main/gdt.h"

#include "proc/sched.h"
#include "proc/proc.h"
#include "proc/kthread.h"
#include "proc/kmutex.h"

#include "drivers/dev.h"
#include "drivers/blockdev.h"
#include "drivers/tty/virtterm.h"

#include "api/exec.h"
#include "api/syscall.h"

#include "fs/vfs.h"
#include "fs/vnode.h"
#include "fs/vfs_syscall.h"
#include "fs/fcntl.h"
#include "fs/stat.h"

#include "test/kshell/kshell.h"
#include "test/kshell/io.h"
#include "errno.h"

#define TESTCASE_1 5
#define TESTCASE_2 3
#define TESTCASE_5 5
#define BUFSIZE 10
#define READ_BUFSIZE 256

typedef unsigned int         sem_t;

GDB_DEFINE_HOOK(boot)
GDB_DEFINE_HOOK(initialized)
GDB_DEFINE_HOOK(shutdown)

static void      *bootstrap(int arg1, void *arg2);
static void      *idleproc_run(int arg1, void *arg2);
static kthread_t *initproc_create(void);
static void      *initproc_run(int arg1, void *arg2);
static void       hard_shutdown(void);
extern void *vfstest_main(int, void*);

static context_t bootstrap_context;
kmutex_t mutex_1, mutex_2;
proc_t *init_process;
int count = 0, global_flag = 0, next_in = 0, next_out = 0, 	value = 1;
int rate_p = 3, rate_c = 3, status, c = 0, d = 0, reparent = 0, drivers = 0;
ktqueue_t barrier_queue, pc_queue;
char buffer[BUFSIZE];
sem_t empty = BUFSIZE;
sem_t occuppied = 0;
pid_t child;
kshell_t *kshell;

/**
 * This is the first real C function ever called. It performs a lot of
 * hardware-specific initialization, then creates a pseudo-context to
 * execute the bootstrap function in.
 */
void
kmain()
{
        GDB_CALL_HOOK(boot);

        dbg_init();
        dbgq(DBG_CORE, "Kernel binary:\n");
        dbgq(DBG_CORE, "  text: 0x%p-0x%p\n", &kernel_start_text, &kernel_end_text);
        dbgq(DBG_CORE, "  data: 0x%p-0x%p\n", &kernel_start_data, &kernel_end_data);
        dbgq(DBG_CORE, "  bss:  0x%p-0x%p\n", &kernel_start_bss, &kernel_end_bss);

        page_init();

        pt_init();
        slab_init();
        pframe_init();

        acpi_init();
        apic_init();
        intr_init();

        gdt_init();

        /* initialize slab allocators */
#ifdef __VM__
        anon_init();
        shadow_init();
#endif
        vmmap_init();
        proc_init();
        kthread_init();

#ifdef __DRIVERS__
        bytedev_init();
        blockdev_init();
#endif

        void *bstack = page_alloc();
        pagedir_t *bpdir = pt_get();
        KASSERT(NULL != bstack && "Ran out of memory while booting.");
        context_setup(&bootstrap_context, bootstrap, 0, NULL, bstack, PAGE_SIZE, bpdir);
        context_make_active(&bootstrap_context);

        panic("\nReturned to kmain()!!!\n");
}

/**
 * This function is called from kmain, however it is not running in a
 * thread context yet. It should create the idle process which will
 * start executing idleproc_run() in a real thread context.  To start
 * executing in the new process's context call context_make_active(),
 * passing in the appropriate context. This function should _NOT_
 * return.
 *
 * Note: Don't forget to set curproc and curthr appropriately.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
bootstrap(int arg1, void *arg2)
{
        /* necessary to finalize page table information */
        pt_template_init();
		dbgq(DBG_INIT,"\n//////////////////////////////In Bootstrap Function/////////////////////////////\n\n");
		dbgq(DBG_INIT,"///////////////////////////Creating the idle process////////////////////////////\n\n");

		/*Creating the first Process -> idle_process*/
		curproc = proc_create("idle_process");
		KASSERT(NULL != curproc);
		dbgq(DBG_INIT,"GRADING1 1.a: The idle process has been created successfully\n");
		KASSERT(PID_IDLE == curproc->p_pid);
		dbgq(DBG_INIT,"GRADING1 1.a: The process that is created is the idle process\n");
        /*Creating thread for the idle_process*/
        curthr = kthread_create(curproc, idleproc_run, 0, NULL);
		KASSERT(NULL != curthr);
		dbgq(DBG_INIT, "GRADING1 1.a: Thread for the idle process has been created successfully\n");
		context_make_active(&curthr->kt_ctx);

        panic("weenix returned to bootstrap()!!! BAD!!!\n");
        return NULL;
}

/**
 * Once we're inside of idleproc_run(), we are executing in the context of the
 * first process-- a real context, so we can finally begin running
 * meaningful code.
 *
 * This is the body of process 0. It should initialize all that we didn't
 * already initialize in kmain(), launch the init process (initproc_run),
 * wait for the init process to exit, then halt the machine.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
idleproc_run(int arg1, void *arg2)
{
        int status;
        pid_t child;

        /* create init proc */
        kthread_t *initthr = initproc_create();

        init_call_all();
        GDB_CALL_HOOK(initialized);

        /* Create other kernel threads (in order) */

#ifdef __VFS__
        /* Once you have VFS remember to set the current working directory
         * of the idle and init processes */
		int return_code, c = 1;
		
		curproc->p_cwd = vfs_root_vn;
		init_process->p_cwd = vfs_root_vn;
		vref(vfs_root_vn);
		vref(vfs_root_vn);
		
        /* Here you need to make the null, zero, and tty devices using mknod */
        /* You can't do this until you have VFS, check the include/drivers/dev.h
         * file for macros with the device ID's you will need to pass to mknod */
        while (c == 1)
        { 
			if((return_code = do_mkdir("/dev")) < 0)
				break;
			
			return_code = do_mknod("/dev/null", S_IFCHR, MEM_NULL_DEVID);		
			
			return_code = do_mknod("/dev/zero", S_IFCHR, MEM_ZERO_DEVID);			

			return_code = do_mknod("/dev/tty0", S_IFCHR, MKDEVID(2, 0));
							
			c++;	
		}

#endif

        /* Finally, enable interrupts (we want to make sure interrupts
         * are enabled AFTER all drivers are initialized) */
        intr_enable();

        /* Run initproc */
        sched_make_runnable(initthr);
        /* Now wait for it */
        child = do_waitpid(-1, 0, &status);
        KASSERT(PID_INIT == child);
        dbgq(DBG_TESTPASS, "TESTCASE1 - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);

#ifdef __MTP__
        kthread_reapd_shutdown();
#endif


#ifdef __VFS__
        /* Shutdown the vfs: */
        dbg_print("weenix: vfs shutdown...\n");
        vput(curproc->p_cwd);
        if (vfs_shutdown())
                panic("vfs shutdown FAILED!!\n");

#endif

        /* Shutdown the pframe system */
#ifdef __S5FS__
        pframe_shutdown();
#endif

        dbg_print("\nweenix: halted cleanly!\n");
        GDB_CALL_HOOK(shutdown);
        hard_shutdown();
        return NULL;
}

/**
 * This function, called by the idle process (within 'idleproc_run'), creates the
 * process commonly refered to as the "init" process, which should have PID 1.
 *
 * The init process should contain a thread which begins execution in
 * initproc_run().
 *
 * @return a pointer to a newly created thread which will execute
 * initproc_run when it begins executing
 */
static kthread_t *
initproc_create(void)
{
	/*Creating the init process*/
	dbgq(DBG_INIT,"\n///////////////////////////Creating the init process////////////////////////////\n\n");
	init_process = proc_create("init_process");
	KASSERT(NULL != init_process);
	dbgq(DBG_INIT, "GRADING1 1.b: The init process has been created successfully\n");
	KASSERT(PID_INIT == init_process->p_pid);
	dbgq(DBG_INIT,"GRADING1 1.b: The process that is created is the init process\n");
    /*Creating thread for the init_process*/
    kthread_t *init_thread = kthread_create(init_process, initproc_run, 0, NULL);
	KASSERT(init_thread != NULL);
	dbgq(DBG_INIT, "GRADING1 1.b: Thread for the init process has been created successfully\n");
        return init_thread;
}

void display_tree()
{
	dbgq(DBG_TESTPASS,"TESTCASE2 - Current working directory \"root\" \n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Current directory structure: \n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - root/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t->proc/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t->new1/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t\t->test1.txt\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t\t->test2/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t->new2/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t\t->bingo1/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t\t->bingo2.txt\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t\t->bingo3/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t->new3/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t\t->cs402/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t\t\t->sample.txt\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t->dev/\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t->tty0\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t->null\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - \t\t->zero\n\n");

	return;

}

static void *test_func_1(int arg1, void *arg2)
{
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 1 BEGINS!!!!--------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	
	int retval;

	do_mkdir("/proc");
	do_mkdir("/proc/new1");
	int fd1=do_open("/proc/new1/test1.txt",O_RDONLY | O_CREAT);
	do_mkdir("/proc/new1/test2");
	do_mkdir("/proc/new2");
	do_mkdir("/proc/new2/bingo1");
	int fd2=do_open("/proc/new2/bingo2.txt",O_RDONLY | O_CREAT);
	do_mkdir("/proc/new2/bingo3");
	do_mkdir("/proc/new3");
	do_mkdir("/proc/new3/cs402");
	int fd3=do_open("/proc/new3/cs402/sample.txt",O_RDONLY | O_CREAT);

	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Catch error messages from mkdir\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to create already existing directory \"cs402\" \n");
	retval=do_mkdir("/proc/new3/cs402");
	if (retval == -EEXIST)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Make directory failed with return code EEXIST \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to create a directory \"Documents\" where some component along the path \"/proc/new2/bingo6/Documents\" does not exist \n");
	retval=do_mkdir("/proc/new2/bingo6/Documents");
	if (retval == -ENOENT)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Make directory failed with return code ENOENT \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to create a directory \"Documents\" where some component along the path \"/proc/new1/test1.txt/Documents\" is not a directory\n");
	retval=do_mkdir("/proc/new1/test1.txt/Documents");
	if (retval == -ENOTDIR)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Make directory failed with return code ENOTDIR \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to create a directory \"DocumentsIsTheNewDirectoryToBeCreated\" where name is too long \n");
	retval=do_mkdir("/proc/new1/test2/DocumentsIsTheNewDirectoryToBeCreated");
	if (retval == -ENAMETOOLONG)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Make directory failed with return code ENAMETOOLONG \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Catch error messages from chdir\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to change current working directory where some component in the path \"/proc/new2/bingo6\" does not exist \n");
	retval=do_chdir("/proc/new2/bingo6");
	if (retval == -ENOENT)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Change directory failed with return code ENOENT \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 -  Trying to change current working directory where some component in the path \"/proc/new1/test1.txt\" is not a directory\n");
	retval=do_chdir("/proc/new1/test1.txt");
	if (retval == -ENOTDIR)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Change directory failed with return code ENOTDIR \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to create a directory \"DocumentsIsTheNewDirectoryToBeCreated\" where name is too long \n");
	retval=do_chdir("/proc/new1/test2/DocumentsIsTheNewDirectoryToBeCreated");
	if (retval == -ENAMETOOLONG)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Change directory failed with return code ENAMETOOLONG \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Catch error messages from rmdir\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to remove a directory \"Documents\" where some component along the path \"/proc/new2/Documents\" does not exist \n");
	retval=do_rmdir("/proc/new2/Documents");
	if (retval == -ENOENT)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Remove directory failed with return code ENOENT \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to remove a directory \"Documents\" where some component along the path \"/proc/new1/test1.txt/Documents\" is not a directory\n");
	retval=do_rmdir("/proc/new1/test1.txt/Documents");
	if (retval == -ENOTDIR)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Remove directory failed with return code ENOTDIR \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to remove a directory \"DocumentsIsTheNewDirectoryToBeCreated\" where name is too long \n");
	retval=do_rmdir("/proc/new1/test2/DocumentsIsTheNewDirectoryToBeCreated");
	if (retval == -ENAMETOOLONG)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Remove directory failed with return code ENAMETOOLONG \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to remove a directory \"cs402\" whose contents are not empty \n");
	retval=do_rmdir("/proc/new3/cs402");
	if (retval == -ENOTEMPTY)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Remove directory failed with return code ENOTEMPTY \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to remove a directory where final component of the path is \"..\" \n");
	retval=do_rmdir("/proc/new3/..");
	if (retval == -ENOTEMPTY)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Remove directory failed with return code ENOTEMPTY \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to remove a directory where final component of the path is \".\" \n");
	retval=do_rmdir("/proc/new1/.");
	if (retval == -EINVAL)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Remove directory failed with return code EINVAL \n");
	
	dbgq(DBG_TESTPASS, "\n-TESTCASE2--------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 1 ENDS!!!!----------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
        
return NULL;
}

int do_testcase_1(kshell_t *ksh, int argc, char **argv)
{
	proc_t *test_proc;
	kthread_t *test_thr;
	pid_t test_pid;

	test_proc = proc_create("testcase_1");
	test_pid = test_proc->p_pid;
	test_thr = kthread_create(test_proc, test_func_1, 0, NULL);
	sched_make_runnable(test_thr);

	child = do_waitpid(test_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE1 - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	
	return 0;
}

static void *test_func_2(int arg1, void *arg2)
{
        int fd, ret;
        char buf[READ_BUFSIZE];
        struct stat s;
		dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
		dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 2 BEGINS!!!!--------------------------------------\n");
		dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
        int test;
        dbgq(DBG_TESTPASS,"TESTCASE2 - Creating Directory \"testing\" in the current working directory\n");
        test=do_mkdir("testing");

        dbgq(DBG_TESTPASS,"TESTCASE2 - Changing Directory to \"testing\"\n");
        test=do_chdir("testing");

        dbgq(DBG_TESTPASS,"TESTCASE2 - Creating file named \"vfs\" in the testing directory and opening it\n");
        strcpy(buf,"First Sentence ends here");
        fd=do_open("/testing/vfs",O_RDWR | O_CREAT);

        dbgq(DBG_TESTPASS,"TESTCASE2 - Writing some data to file named \"vfs\" in the testing directory\n");
        test=do_write(fd,buf,strlen(buf));
		do_lseek(fd, 0 ,0);
        dbgq(DBG_TESTPASS,"TESTCASE2 - Reading from file \"vfs\" in the testing directory\n");
        test=do_read(fd,buf,sizeof(buf));
        buf[test]='\0';

        dbgq(DBG_TESTPASS,"TESTCASE2 - Content of  file is => '%s'  and number of bytes read is '%d'\n",buf,test);
        dbgq(DBG_TESTPASS,"TESTCASE2 - Seeking to position 5 in the file \"vfs\"  in mode SEEK_SET\n ");
        test=do_lseek(fd,5,0);

        strcpy(buf,"Second sentence inserted here");
        dbgq(DBG_TESTPASS,"TESTCASE2 - Writing some data to the file named \"vfs\" in the testing directory from position 5\n");
        test=do_write(fd,buf,strlen(buf));
        strcpy(buf,"");
		do_lseek(fd, 0 ,0);
		dbgq(DBG_TESTPASS,"TESTCASE2 - Reading from file \"vfs\"...\n");
        test=do_read(fd,buf,sizeof(buf));
        buf[test]='\0';

        dbgq(DBG_TESTPASS,"TESTCASE2 - Content of file is => '%s'  and number of bytes read is '%d'\n",buf,test);

        dbgq(DBG_TESTPASS,"TESTCASE2 - Seeking to the  cursor position in the file \"vfs\" with mode SEEK_CUR and writing some data to the file\n");
        test=do_lseek(fd,0,1);

        strcpy(buf,"");
        strcpy(buf,"Cursor Text is here");
        test=do_write(fd,buf,strlen(buf));
		do_lseek(fd, 0 ,0);
		dbgq(DBG_TESTPASS,"TESTCASE2 - Reading from file \"vfs\"...\n");
        test=do_read(fd,buf,sizeof(buf));
        buf[test]='\0';

        dbgq(DBG_TESTPASS,"TESTCASE2 - Content of file is => '%s' and number of bytes read is '%d'\n",buf,test);

        dbgq(DBG_TESTPASS,"TESTCASE2 - Seeking to the last cursor position in the file \"vfs\" with mode SEEK_END\n");
        test=do_lseek(fd,0,2);

        strcpy(buf,"");
        strcpy(buf,"New Text is written at the end");
        test=do_write(fd,buf,strlen(buf));
		do_lseek(fd, 0 ,0);
		dbgq(DBG_TESTPASS,"TESTCASE2 - Reading from file \"vfs\"...\n");
        test=do_read(fd,buf,sizeof(buf));
        buf[test]='\0';

        dbgq(DBG_TESTPASS,"TESTCASE2 - Content of new file after last cursor is => '%s' and number of bytes read is '%d'\n",buf,test);
        test=do_close(fd);

        dbgq(DBG_TESTPASS,"TESTCASE2 - Unlinking the file named \"vfs\"\n");
        test=do_unlink("/testing/vfs");

        dbgq(DBG_TESTPASS,"TESTCASE2 - Removing the directory named \"testing\"\n");
        test=do_rmdir("/testing");
		dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
		dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 2 ENDS--!!!!--------------------------------------\n");
		dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
return 0;
}

int do_testcase_2(kshell_t *ksh, int argc, char **argv)
{
	proc_t *test_proc;
	kthread_t *test_thr;
	pid_t test_pid;

	test_proc = proc_create("testcase_2");
	test_pid = test_proc->p_pid;
	test_thr = kthread_create(test_proc, test_func_2, 0, NULL);
	sched_make_runnable(test_thr);

	child = do_waitpid(test_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE1 - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	
	return 0;
}

static void ls(int argc, char *argv)
{
	int fd, i, j;
	dirent_t dirp;
	char path[100];
	char *name[10];
	struct stat statbuf;
	
	for(i = 0; i < 10; i++)
		name[i] = kmalloc(NAME_LEN);
		
	i = 0;	
	fd = do_open(argv, O_RDONLY);
	dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_getdent() and get the entries inside '%s'!!!!\n",argv);
	dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_stat() on each entry inside '%s' to determine their modes!!!!\n",argv);
	dbgq(DBG_TESTPASS, "TESTCASE2 - directory entries will be appended with '/' and just name for regular files!!!!\n");
	while(do_getdent(fd, &dirp) == sizeof(dirent_t))
	{
		strcpy(path,argv);
		path[strlen(argv)] = '/';
		path[strlen(argv)+1] = '\0';
		strcat(path, dirp.d_name);
		do_stat(path, &statbuf);
		strcpy(name[i], dirp.d_name);
		if(S_ISDIR(statbuf.st_mode))
		{
			name[i][strlen(dirp.d_name)] = '/';
			name[i][strlen(dirp.d_name)+1] = '\0';
		}		
		i++;
	}
	dbgq(DBG_TESTPASS, "TESTCASE2 - do_getdent() & do_stat() returned successfully!!!!\n");
	dbgq(DBG_TESTPASS, "TESTCASE2 - here is the list of files and directories inside '%s'!!!!\n",argv);	
	for(j = 0; j< i; j++)
	{
		dbgq(DBG_TESTPASS, "TESTCASE2 - %s\n",name[j]);
	}
	dbgq(DBG_TESTPASS, "\n");
	
	for(i = 0; i < 10; i++)
		kfree(name[i]);
		
}

void create_max_open_files()
{
	int i=0;
	char filename[NAME_LEN];
	char filenum[10];
	for(i=1;i<=NFILES;i++)
	{
		strcpy(filename,"/proc/new2/rand");
		sprintf(filenum,"%d",i);
		strcat(filename,filenum);
		strcat(filename,".txt");
		int retval=do_open(filename,O_RDWR | O_CREAT);
		if (retval < 0)
			dbgq(DBG_TESTPASS,"TESTCASE2 - open failed unexpected %d\n",retval);
	}
	return;
}

void close_all_open_files()
{
	int i=0;
	for(i=0;i<NFILES;i++)
	{
		do_close(i);
	}
	return;
}

void unlink_files_created()
{
	int i=0;
	char filename[NAME_LEN];
	char filenum[10];
	for(i=1;i<=NFILES;i++)
	{
		strcpy(filename,"/proc/new2/rand");
		sprintf(filenum,"%d",i);
		strcat(filename,filenum);
		strcat(filename,".txt");
		int retval=do_unlink(filename);
		if (retval < 0)
			dbgq(DBG_TESTPASS,"TESTCASE2 - unlink failed unexpected %d\n",retval);
	}
	return;
}

static void *test_func_3(int arg1, void *arg2)
{
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 3 BEGINS!!!!--------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	
	int retval;

	display_tree();

	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Catch error messages from open system call\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to open which does not exist and O_CREAT flag is not set \n");
	int fd1=do_open("/proc/new1/rand1.txt",O_RDONLY);
	if(fd1 == -ENOENT)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Open failed with return code ENOENT\n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to open with invalid oflags paramater \n");
	int fd2=do_open("/proc/new1/test1.txt",5);
	if(fd2 == -EINVAL)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Open failed with return code EINVAL\n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to open more files than the max allowed per process \n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Currently the process has no open files\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Opening files to reach the max allowed per process\n");
	create_max_open_files();
	dbgq(DBG_TESTPASS,"TESTCASE2 - Now process has reached max amount of files that can be opened.Trying to open another file now...\n");
	int fd3=do_open("/proc/new2/rand30.txt",O_RDONLY | O_CREAT);
	if(fd3 == -EMFILE)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Open failed with return code EMFILE\n");
	close_all_open_files();
	unlink_files_created();

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to open a file \"ThisIsTheNewFileToBeCreatedAndOpened\" where name is too long with O_CREAT flag set\n");
	int fd4=do_open("/proc/new1/test2/DocumentsIsTheNewDirectoryToBeCreated",O_WRONLY | O_CREAT);
	if (fd4 == -ENAMETOOLONG)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Open failed with return code ENAMETOOLONG \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to open a directory \"cs402\" \n");
	int fd5=do_open("/proc/new3/cs402",O_WRONLY);
	if (fd5 == -EISDIR)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Open failed with return code EISDIR \n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Catch error messages from dup system call\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to dup a file which has invalid fd number\n");
	fd1=do_dup(3);
	if(fd1 == -EBADF)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Dup failed with return code EBADF\n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to dup more files than the max allowed per process \n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Currently the process has no open files\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Opening a file and it is dup'ed to reach the max allowed fd per process\n");
	fd2=do_open("/proc/new2/bingo2.txt",O_RDONLY);
	int i=0;
	for(i=1;i<NFILES;i++)
	{
		int dup_fd=do_dup(fd2);
		if(dup_fd <=0)
			dbgq(DBG_TESTFAIL,"TESTCASE2 - Dup failed unexpected\n");
	}
	dbgq(DBG_TESTPASS,"TESTCASE2 - Now process has reached max amount of files that can be opened.Trying to dup same file once more now...\n");
	fd3=do_dup(fd2);
	if(fd3 == -EMFILE)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Dup failed with return code EMFILE\n");
	for(i=0;i<NFILES;i++)
	{
		int close_fd=do_close(i);
		if(close_fd < 0)
			dbgq(DBG_TESTFAIL,"TESTCASE2 - Close failed unexpected\n");
	}


	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Catch error messages from dup2 system call\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to dup2 a file which has invalid ofd number\n");
	fd1=do_dup2(3,4);
	if(fd1 == -EBADF)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Dup2 failed with return code EBADF\n");


	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to dup2 a file which has invalid nfd number\n");
	int ofd=do_open("/proc/new1/test1.txt",O_RDONLY);
	int nfd=do_dup2(ofd,32);
	if(nfd == -EBADF)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Dup2 failed with return code EBADF\n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - Catch error messages from close system call\n");
	dbgq(DBG_TESTPASS,"TESTCASE2 - **************************************************\n");

	dbgq(DBG_TESTPASS,"TESTCASE2 - Trying to close a file which has invalid fd number\n");
	fd1=do_dup(3);
	if(fd1 == -EBADF)
		dbgq(DBG_TESTPASS,"TESTCASE2 - Close failed with return code EBADF\n");


	do_chdir("/");
	do_unlink("/proc/new1/test1.txt");
	do_unlink("/proc/new2/bingo2.txt");
	do_unlink("/proc/new3/cs402/sample.txt");
	do_rmdir("/proc/new3/cs402");
	do_rmdir("/proc/new3/");
	do_rmdir("/proc/new2/bingo1");
	do_rmdir("/proc/new2/bingo3");
	do_rmdir("/proc/new2/");
	do_rmdir("/proc/new1/test2");
	do_rmdir("/proc/new1/");
	do_rmdir("/proc/");
	
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 3 ENDS!!!!----------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
        
return NULL;
}

int do_testcase_3(kshell_t *ksh, int argc, char **argv)
{
	proc_t *test_proc;
	kthread_t *test_thr;
	pid_t test_pid;

	test_proc = proc_create("testcase_3");
	test_pid = test_proc->p_pid;
	test_thr = kthread_create(test_proc, test_func_3, 0, NULL);
	sched_make_runnable(test_thr);

	child = do_waitpid(test_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE1 - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	
	return 0;
}

static void *test_func_4(int arg1, void *arg2)
{
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 4 BEGINS!!!!--------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	
	dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_mkdir() to create the directory 'testcase_4'!!!!\n");
    do_mkdir("testcase_4");
    dbgq(DBG_TESTPASS, "TESTCASE2 - directory 'testcase_4' created successfully!!!!\n");
    dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_chdir() to change directory to 'testcase_4'!!!!\n");
    do_chdir("testcase_4");
    dbgq(DBG_TESTPASS, "TESTCASE2 - curproc's current working directory is now 'testcase_4'!!!!\n");
    dbgq(DBG_TESTPASS, "TESTCASE2 - creating directories 'SASI' and 'SATHISH' inside 'testcase_4'!!!!\n");
    do_mkdir("SASI");
    do_mkdir("SATHISH");	
	do_chdir("SASI");
	dbgq(DBG_TESTPASS, "TESTCASE2 - creating file 'file01.txt' inside directory 'SASI'!!!!\n");
	do_open("file01.txt",O_RDWR|O_CREAT);
	do_chdir("..");
	dbgq(DBG_TESTPASS, "TESTCASE2 - listing contents of 'SATHISH' before link operation!!!!\n");
	ls(1, "SATHISH");
	dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_link() to create a link from 'SASI/file01.txt' to 'SATHISH/file02.txt'!!!!\n");
	do_link("SASI/file01.txt","SATHISH/file02.txt");
	dbgq(DBG_TESTPASS, "TESTCASE2 - listing contents of 'SATHISH' after link!!!!\n");
	ls(1, "SATHISH");
	dbgq(DBG_TESTPASS, "TESTCASE2 - listing contents of 'SASI' before rename operation!!!!\n");
	ls(1, "SASI");
	do_chdir("SASI");
	dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_rename() to rename 'file01.txt' to 'file03.txt'!!!!\n");
	do_rename("file01.txt","file03.txt");
	do_chdir("..");
	dbgq(DBG_TESTPASS, "TESTCASE2 - listing contents of 'SASI' after rename operation!!!!\n");
	ls(1, "SASI");
	dbgq(DBG_TESTPASS, "TESTCASE2 - Removing directories and files created for this testcase\n");
	do_chdir("SASI");
	do_unlink("file03.txt");
	do_chdir("..");
	do_rmdir("SASI");
	dbgq(DBG_TESTPASS, "TESTCASE2 - directory 'SASI' and its entry 'file03.txt' are removed successfully\n");
	do_chdir("SATHISH");
	do_unlink("file02.txt");
	do_chdir("..");
	do_rmdir("SATHISH");
	dbgq(DBG_TESTPASS, "TESTCASE2 - directory 'SATHISH' and its entry 'file02.txt' are removed successfully\n");
	do_chdir("..");
	do_rmdir("testcase_4");	
	dbgq(DBG_TESTPASS, "TESTCASE2 - directory 'testcase_4' is removed successfully\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 4 ENDS!!!!----------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");    
        
    return NULL;
}

int do_testcase_4(kshell_t *ksh, int argc, char **argv)
{
	proc_t *test_proc;
	kthread_t *test_thr;
	pid_t test_pid;

	test_proc = proc_create("testcase_4");
	test_pid = test_proc->p_pid;
	test_thr = kthread_create(test_proc, test_func_4, 0, NULL);
	sched_make_runnable(test_thr);

	child = do_waitpid(test_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE1 - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	
	return 0;
}

static void *test_func_5(int arg1, void *arg2)
{
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 5 BEGINS!!!!--------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_mkdir() to create the directory 'testcase_5'!!!!\n");
    do_mkdir("testcase_5");
    dbgq(DBG_TESTPASS, "TESTCASE2 - directory 'testcase_5' created successfully!!!!\n");
    dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_chdir() to change directory to 'testcase_5'!!!!\n");
    do_chdir("testcase_5");
    dbgq(DBG_TESTPASS, "TESTCASE2 - curproc's current working directory is now 'testcase_5'!!!!\n");
    dbgq(DBG_TESTPASS, "TESTCASE2 - creating few more directories and a file inside 'testcase_5'!!!!\n");
    do_mkdir("SASI");
    do_mkdir("SATHISH");

    do_open("file01.txt",O_RDWR|O_CREAT);
    dbgq(DBG_TESTPASS, "TESTCASE2 - changing directory back to the parent directory!!!!\n");
    do_chdir("..");
    dbgq(DBG_TESTPASS, "TESTCASE2 - calling our implementation of 'ls' to list contents of 'testcase_5'!!!!\n");
    ls(1, "testcase_5");
    dbgq(DBG_TESTPASS, "TESTCASE2 - trying to delete 'testcase_5'!!!!\n");
    int return_code = do_rmdir("testcase_5");
    dbgq(DBG_TESTPASS, "TESTCASE2 - returns with errno %d - DIRECTORY NOT EMPTY!!!!\n",return_code);
    do_chdir("testcase_5");
	dbgq(DBG_TESTPASS, "TESTCASE2 - trying to create a directory with the same of an already existing directory!!!!\n");
    return_code = do_mkdir("SASI");
    dbgq(DBG_TESTPASS, "TESTCASE2 - return with errno %d - DIRECTORY OR FILE ALREADY EXISTS!!!!\n",return_code);
    dbgq(DBG_TESTPASS, "TESTCASE2 - deleting entries within 'testcase_5'!!!!\n");
    dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_rmdir() on the directory entries!!!!\n");    
    do_rmdir("SASI");
    do_rmdir("SATHISH");
	dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_unlink() on the regular file entries!!!!\n");
    do_unlink("file01.txt");
    
    do_chdir("..");
    dbgq(DBG_TESTPASS, "TESTCASE2 - all entries inside 'testcase_5' deleted successfully!!!!\n");
    dbgq(DBG_TESTPASS, "TESTCASE2 - calling our implementation of 'ls' to list contents of 'testcase_5'!!!!\n");
    ls(1, "testcase_5");
    dbgq(DBG_TESTPASS, "TESTCASE2 - trying to delete directory 'testcase_5'!!!!\n");
    do_rmdir("testcase_5");
    dbgq(DBG_TESTPASS, "TESTCASE2 - directory 'testcase_5' deleted successfully!!!!\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 5 ENDS!!!!----------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");    
        
    return NULL;
}

int do_testcase_5(kshell_t *ksh, int argc, char **argv)
{
	proc_t *test_proc;
	kthread_t *test_thr;
	pid_t test_pid;

	test_proc = proc_create("testcase_5");
	test_pid = test_proc->p_pid;
	test_thr = kthread_create(test_proc, test_func_5, 0, NULL);
	sched_make_runnable(test_thr);

	child = do_waitpid(test_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE1 - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	
	return 0;
}

static void *test_func_6(int arg1, void *arg2)
{
	int fd[2];
	
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 6 BEGINS!!!!--------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_mkdir() to create the directory 'testcase_6'!!!!\n");
    do_mkdir("testcase_6");
    dbgq(DBG_TESTPASS, "TESTCASE2 - directory 'testcase_6' created successfully!!!!\n");
    dbgq(DBG_TESTPASS, "TESTCASE2 - calling do_chdir() to change directory to 'testcase_6'!!!!\n");
    do_chdir("testcase_6");
    dbgq(DBG_TESTPASS, "TESTCASE2 - curproc's current working directory is now 'testcase_6'!!!!\n");
	
	dbgq(DBG_TESTPASS, "TESTCASE2 - creating and opening three new files!!!!\n");
	fd[0] = do_open("file01.txt", O_RDWR|O_CREAT);
	fd[1] = do_open("file02.txt", O_RDWR|O_CREAT);
	fd[2] = do_open("file03.txt", O_RDWR|O_CREAT);
	dbgq(DBG_TESTPASS, "TESTCASE2 - file descriptors now in use are %d, %d, %d!!!!\n",fd[0],fd[1],fd[2]);
	
	dbgq(DBG_TESTPASS, "TESTCASE2 - duplicating all the three files created!!!!\n");
	fd[3] = do_dup(fd[0]);
	fd[4] = do_dup(fd[1]);
	fd[5] = do_dup(fd[2]);
	dbgq(DBG_TESTPASS, "TESTCASE2 - file descriptors now in use are %d, %d, %d, %d, %d, %d!!!!\n",fd[0],fd[1],fd[2],fd[3],fd[4],fd[5]);
	
	dbgq(DBG_TESTPASS, "TESTCASE2 - duplicating file on file descriptor %d with file descriptor %d which is already in open!!!!\n", fd[0], fd[5]);
	fd[6] = do_dup2(fd[0], 5);
	dbgq(DBG_TESTPASS, "TESTCASE2 - file descriptors now in use are %d, %d, %d, %d, %d, %d!!!!\n",fd[0],fd[1],fd[2],fd[3],fd[4],fd[6]);

    do_unlink("file01.txt");
    do_unlink("file02.txt");
    do_unlink("file03.txt");
	dbgq(DBG_TESTPASS, "TESTCASE2 - deleted the three files created!!!!\n");
	do_chdir("..");
    dbgq(DBG_TESTPASS, "TESTCASE2 - calling our implementation of 'ls' to list contents of 'testcase_6'!!!!\n");
    ls(1, "testcase_6");
    dbgq(DBG_TESTPASS, "TESTCASE2 - trying to delete directory 'testcase_6'!!!!\n");

    do_rmdir("testcase_6");
    dbgq(DBG_TESTPASS, "TESTCASE2 - directory 'testcase_6' deleted successfully!!!!\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 6 ENDS!!!!----------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");    
        
    return NULL;
}

int do_testcase_6(kshell_t *ksh, int argc, char **argv)
{
	proc_t *test_proc;
	kthread_t *test_thr;
	pid_t test_pid;

	test_proc = proc_create("testcase_6");
	test_pid = test_proc->p_pid;
	test_thr = kthread_create(test_proc, test_func_6, 0, NULL);
	sched_make_runnable(test_thr);

	child = do_waitpid(test_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE1 - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	
	return 0;
}

static void *test_func_7(int arg1, void *arg2)
{
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 7 BEGINS!!!!--------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	
	vfstest_main(1, NULL);
	
	dbgq(DBG_TESTPASS, "\nTESTCASE2-----------------------VFSTEST.C TESTCASES RUN SUCCESSFULLY----------------------------------------\n");
	
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");
	dbgq(DBG_TESTPASS, "\n--------------------------------TESTCASE2 - TESTCASE No.. 7 ENDS!!!!----------------------------------------\n");
	dbgq(DBG_TESTPASS, "\nTESTCASE2---------------------------------------------------------------------------------------------------\n");

    return NULL;
}

int do_testcase_7(kshell_t *ksh, int argc, char **argv)
{
	proc_t *test_proc;
	kthread_t *test_thr;
	pid_t test_pid;

	test_proc = proc_create("testcase_7");
	test_pid = test_proc->p_pid;
	test_thr = kthread_create(test_proc, test_func_7, 0, NULL);
	sched_make_runnable(test_thr);

	child = do_waitpid(test_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE1 - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	
	return 0;
}

static void *kshell_func(int arg1, void *arg2)
{
    kshell_add_command("test_1", do_testcase_1, "run 'do_testcase_1' testcases");
    kshell_add_command("test_2", do_testcase_2, "run 'do_testcase_2' testcases");
    kshell_add_command("test_3", do_testcase_3, "run 'do_testcase_3' testcases");
    kshell_add_command("test_4", do_testcase_4, "run 'do_testcase_4' testcases");
    kshell_add_command("test_5", do_testcase_5, "run 'do_testcase_5' testcases");
    kshell_add_command("test_6", do_testcase_6, "run 'do_testcase_6' testcases");
    kshell_add_command("vfstest", do_testcase_7, "run 'vfstest.c' testcases"); 
    
    kshell = kshell_create(0);
    if (NULL == kshell) panic("init: Couldn't create kernel shell\n");
  
    while (kshell_execute_next(kshell));
    kshell_destroy(kshell);

    return NULL;
}

static void do_testcase_8()
{
	proc_t *kshell_proc;
	kthread_t *kshell_thr;
	pid_t kshell_pid;

	kshell_proc = proc_create("kshell_proc");
	kshell_pid = kshell_proc->p_pid;
	kshell_thr = kthread_create(kshell_proc, kshell_func, 0, NULL);
	sched_make_runnable(kshell_thr);

	child = do_waitpid(kshell_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE1 - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
}



/**
 * The init thread's function changes depending on how far along your Weenix is
 * developed. Before VM/FI, you'll probably just want to have this run whatever
 * tests you've written (possibly in a new process). After VM/FI, you'll just
 * exec "/bin/init".
 *
 * Both arguments are unused.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
initproc_run(int arg1, void *arg2)
{    
    do_testcase_1(kshell, 0 , NULL);
    
    do_testcase_2(kshell, 0 , NULL);
    
    do_testcase_3(kshell, 0 , NULL);
    
    do_testcase_4(kshell, 0 , NULL);
    
    do_testcase_5(kshell, 0 , NULL);
    
    do_testcase_6(kshell, 0 , NULL);
    
    do_testcase_7(kshell, 0 , NULL);
    
    #ifdef __DRIVERS__

	do_testcase_8();

    #endif /* __DRIVERS__ */

   return NULL;
}

/**
 * Clears all interrupts and halts, meaning that we will never run
 * again.
 */
static void
hard_shutdown()
{
#ifdef __DRIVERS__
        vt_print_shutdown();
#endif
        __asm__ volatile("cli; hlt");
}
