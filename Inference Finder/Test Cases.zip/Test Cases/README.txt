Following are the commands to run different tasks on knowledge bases. The 2nd knowledge base is not satisfiable, so we don't need to run task3 on that.

Task (1) 
	
	> program -task1 kb1.txt kb1-task1-output.txt
	> program -task1 kb2.txt kb2-task1-output.txt

Task (2)

	> program -task2 kb1.txt kb1-task2-output.txt
	> program -task2 kb2.txt kb2-task2-output.txt

Task (3)

	> program -task3 kb1.txt statements1.txt kb1-task3-output.txt
