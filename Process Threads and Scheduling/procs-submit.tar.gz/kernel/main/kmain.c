#include "types.h"
#include "globals.h"
#include "kernel.h"

#include "util/gdb.h"
#include "util/init.h"
#include "util/list.h"
#include "util/debug.h"
#include "util/string.h"
#include "util/printf.h"

#include "mm/mm.h"
#include "mm/page.h"
#include "mm/pagetable.h"
#include "mm/pframe.h"

#include "vm/vmmap.h"
#include "vm/shadow.h"
#include "vm/anon.h"

#include "main/acpi.h"
#include "main/apic.h"
#include "main/interrupt.h"
#include "main/cpuid.h"
#include "main/gdt.h"

#include "proc/sched.h"
#include "proc/proc.h"
#include "proc/kthread.h"
#include "proc/kmutex.h"

#include "drivers/dev.h"
#include "drivers/blockdev.h"
#include "drivers/tty/virtterm.h"

#include "api/exec.h"
#include "api/syscall.h"

#include "fs/vfs.h"
#include "fs/vnode.h"
#include "fs/vfs_syscall.h"
#include "fs/fcntl.h"
#include "fs/stat.h"

#include "test/kshell/kshell.h"
#include "test/kshell/io.h"

#define TESTCASE_1 5
#define TESTCASE_2 3
#define TESTCASE_5 5
#define BUFSIZE 10

typedef unsigned int         sem_t;

GDB_DEFINE_HOOK(boot)
GDB_DEFINE_HOOK(initialized)
GDB_DEFINE_HOOK(shutdown)

static void      *bootstrap(int arg1, void *arg2);
static void      *idleproc_run(int arg1, void *arg2);
static kthread_t *initproc_create(void);
static void      *initproc_run(int arg1, void *arg2);
static void       hard_shutdown(void);

static context_t bootstrap_context;
kmutex_t mutex_1, mutex_2;
proc_t *init_process;
int count = 0, global_flag = 0, next_in = 0, next_out = 0, 	value = 1;
int rate_p = 3, rate_c = 3, status, c = 0, d = 0, reparent = 0, drivers = 0;
ktqueue_t barrier_queue, pc_queue;
char buffer[BUFSIZE];
sem_t empty = BUFSIZE;
sem_t occuppied = 0;
pid_t child;
kshell_t *kshell;

/**
 * This is the first real C function ever called. It performs a lot of
 * hardware-specific initialization, then creates a pseudo-context to
 * execute the bootstrap function in.
 */
void
kmain()
{
        GDB_CALL_HOOK(boot);

        dbg_init();
        dbgq(DBG_CORE, "Kernel binary:\n");
        dbgq(DBG_CORE, "  text: 0x%p-0x%p\n", &kernel_start_text, &kernel_end_text);
        dbgq(DBG_CORE, "  data: 0x%p-0x%p\n", &kernel_start_data, &kernel_end_data);
        dbgq(DBG_CORE, "  bss:  0x%p-0x%p\n", &kernel_start_bss, &kernel_end_bss);

        page_init();

        pt_init();
        slab_init();
        pframe_init();

        acpi_init();
        apic_init();
        intr_init();

        gdt_init();

        /* initialize slab allocators */
#ifdef __VM__
        anon_init();
        shadow_init();
#endif
        vmmap_init();
        proc_init();
        kthread_init();

#ifdef __DRIVERS__
        bytedev_init();
        blockdev_init();
#endif

        void *bstack = page_alloc();
        pagedir_t *bpdir = pt_get();
        KASSERT(NULL != bstack && "Ran out of memory while booting.");
        context_setup(&bootstrap_context, bootstrap, 0, NULL, bstack, PAGE_SIZE, bpdir);
        context_make_active(&bootstrap_context);

        panic("\nReturned to kmain()!!!\n");
}

/**
 * This function is called from kmain, however it is not running in a
 * thread context yet. It should create the idle process which will
 * start executing idleproc_run() in a real thread context.  To start
 * executing in the new process's context call context_make_active(),
 * passing in the appropriate context. This function should _NOT_
 * return.
 *
 * Note: Don't forget to set curproc and curthr appropriately.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
bootstrap(int arg1, void *arg2)
{
        /* necessary to finalize page table information */
        pt_template_init();
		dbgq(DBG_INIT,"\n//////////////////////////////In Bootstrap Function/////////////////////////////\n\n");
		dbgq(DBG_INIT,"///////////////////////////Creating the idle process////////////////////////////\n\n");

		/*Creating the first Process -> idle_process*/
		curproc = proc_create("idle_process");
		KASSERT(NULL != curproc);
		dbgq(DBG_INIT,"GRADING 1.a: The idle process has been created successfully\n");

		KASSERT(PID_IDLE == curproc->p_pid);
		dbgq(DBG_INIT,"GRADING 1.a: The process that is created is the idle process\n");

        /*Creating thread for the idle_process*/
        curthr = kthread_create(curproc, idleproc_run, 0, NULL);
		KASSERT(NULL != curthr);
		dbgq(DBG_INIT, "GRADING 1.a: Thread for the idle process has been created successfully\n");

		context_make_active(&curthr->kt_ctx);

        panic("weenix returned to bootstrap()!!! BAD!!!\n");
        return NULL;
}

/**
 * Once we're inside of idleproc_run(), we are executing in the context of the
 * first process-- a real context, so we can finally begin running
 * meaningful code.
 *
 * This is the body of process 0. It should initialize all that we didn't
 * already initialize in kmain(), launch the init process (initproc_run),
 * wait for the init process to exit, then halt the machine.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
idleproc_run(int arg1, void *arg2)
{
        int status;
        pid_t child;

        /* create init proc */
        kthread_t *initthr = initproc_create();

        init_call_all();
        GDB_CALL_HOOK(initialized);

        /* Create other kernel threads (in order) */

#ifdef __VFS__
        /* Once you have VFS remember to set the current working directory
         * of the idle and init processes */

        /* Here you need to make the null, zero, and tty devices using mknod */
        /* You can't do this until you have VFS, check the include/drivers/dev.h
         * file for macros with the device ID's you will need to pass to mknod */
#endif

        /* Finally, enable interrupts (we want to make sure interrupts
         * are enabled AFTER all drivers are initialized) */
        intr_enable();

        /* Run initproc */
        sched_make_runnable(initthr);
        /* Now wait for it */
        child = do_waitpid(-1, 0, &status);
        KASSERT(PID_INIT == child);
        dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);

#ifdef __MTP__
        kthread_reapd_shutdown();
#endif


#ifdef __VFS__
        /* Shutdown the vfs: */
        dbg_print("weenix: vfs shutdown...\n");
        vput(curproc->p_cwd);
        if (vfs_shutdown())
                panic("vfs shutdown FAILED!!\n");

#endif

        /* Shutdown the pframe system */
#ifdef __S5FS__
        pframe_shutdown();
#endif

        dbg_print("\nweenix: halted cleanly!\n");
        GDB_CALL_HOOK(shutdown);
        hard_shutdown();
        return NULL;
}

/**
 * This function, called by the idle process (within 'idleproc_run'), creates the
 * process commonly refered to as the "init" process, which should have PID 1.
 *
 * The init process should contain a thread which begins execution in
 * initproc_run().
 *
 * @return a pointer to a newly created thread which will execute
 * initproc_run when it begins executing
 */
static kthread_t *
initproc_create(void)
{
	/*Creating the init process*/
	dbgq(DBG_INIT,"\n///////////////////////////Creating the init process////////////////////////////\n\n");
	init_process = proc_create("init_process");
	KASSERT(NULL != init_process);
	dbgq(DBG_INIT, "GRADING 1.b: The init process has been created successfully\n");

	KASSERT(PID_INIT == init_process->p_pid);
	dbgq(DBG_INIT,"GRADING 1.b: The process that is created is the init process\n");

    /*Creating thread for the init_process*/
    kthread_t *init_thread = kthread_create(init_process, initproc_run, 0, NULL);
	KASSERT(init_thread != NULL);
	dbgq(DBG_INIT, "GRADING 1.b: Thread for the init process has been created successfully\n");

        return init_thread;
}

void print_rows()
{
	int i = 0;
	dbgq(DBG_TEST,"\n");
	for(i=0;i<80;i++)
	{
		if(i == 0 || i == 79)
		{	
			dbgq(DBG_TESTPASS,"+");
		}
		else
		{
			dbgq(DBG_TESTPASS,"-");
		}	
	}
	dbgq(DBG_TEST,"\n");
}

static void *getprocname()
{
	int i;
		for(i=0;curproc->p_comm[i]!='\0';i++)
		{
			dbgq(DBG_TESTPASS,"%c",curproc->p_comm[i]);	
		}	
		return NULL;
}

static void *get_child_name(char *name)
{
	int i;
		for(i=0;i<(int) strlen(name);i++)
		{	
			dbgq(DBG_TESTPASS,"%c",name[i]);
		}	
		return NULL;
}

static void *print_stats(int arg1, void *arg2)
{
		dbgq(DBG_TESTPASS,"\nTESTCASE - CREATE: The Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d created successfully!!!\n",curproc->p_pid);

		dbgq(DBG_TESTPASS,"TESTCASE - Thread for Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' created successfully\n");
		
		dbgq(DBG_TESTPASS,"TESTCASE - Executing inside the Process's Thread!!!\n");
		
		return NULL;
}

static void *shared_data_proc1(int arg1, void *arg2)
{
		dbgq(DBG_TESTPASS,"\nTESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d is attempting to lock Mutex!!!!\n",curproc->p_pid);

		kmutex_lock(&mutex_1);

		dbgq(DBG_TESTPASS,"\nTESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to lock Mutex: SUCCESS!!!!\n",curproc->p_pid);
		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d services its customers until another thread wakes it up!!!!\n",curproc->p_pid);

		sched_sleep_on(&curproc->p_wait);

		dbgq(DBG_TESTPASS,"\nTESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d finished its service... Attempting to unlock Mutex!!!!\n",curproc->p_pid);

		kmutex_unlock(&mutex_1);

		dbgq(DBG_TESTPASS,"\nTESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to unlock Mutex: SUCCESS!!!!\n",curproc->p_pid);

		return NULL;
}

static void *shared_data_proc2()
{
		proc_t *p;
		kthread_t *thr;
		list_iterate_begin(&curproc->p_children, p, proc_t, p_child_link)
		{
			list_iterate_begin(&p->p_threads, thr, kthread_t, kt_plink)
			{
				if((thr->kt_state == KT_SLEEP)|| (thr->kt_state == KT_SLEEP_CANCELLABLE))
					{
						sched_wakeup_on(&p->p_wait);
					}
			}list_iterate_end();
		}list_iterate_end();
		return NULL;
}

static void *deadlock_proc1(int arg1, void *arg2)
{
		dbgq(DBG_TESTPASS,"\nTESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d is attempting to lock Mutex 1!!!!\n",curproc->p_pid);

		kmutex_lock(&mutex_1);

		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to lock Mutex 1: SUCCESS!!!!\n",curproc->p_pid);
		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d services its customers until another thread wakes it up!!!!\n",curproc->p_pid);

		sched_make_runnable(curthr);
		sched_switch();

		dbgq(DBG_TESTPASS,"\nTESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d is attempting to lock Mutex 2!!!!\n",curproc->p_pid);

		if(kmutex_lock_cancellable(&mutex_2))
		{
			dbgq(DBG_TESTPASS,"\nTESTCASE - The killed Process '");
			getprocname();
			dbgq(DBG_TESTPASS,"' with PID %d enters its cancellation routine !!!!\n",curproc->p_pid);
			kmutex_unlock(&mutex_1);
			dbgq(DBG_TESTPASS,"Unlocked Mutex 1 and exiting\n!!!");
			kthread_exit((void *)0);
		}

		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to lock Mutex 2: SUCCESS!!!!\n",curproc->p_pid);

		kmutex_unlock(&mutex_2);

		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to unlock Mutex 2: SUCCESS!!!!\n",curproc->p_pid);

		kmutex_unlock(&mutex_1);

		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to unlock Mutex 1: SUCCESS!!!!\n",curproc->p_pid);

		return NULL;
}

static void *deadlock_proc2(int arg1, void *arg2)
{
		dbgq(DBG_TESTPASS,"\nTESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d is attempting to lock Mutex 2!!!!\n",curproc->p_pid);

		kmutex_lock(&mutex_2);

		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to lock Mutex 2: SUCCESS!!!!\n",curproc->p_pid);

		shared_data_proc2(0,NULL);

		dbgq(DBG_TESTPASS,"\nTESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d is attempting to lock Mutex 1!!!!\n",curproc->p_pid);

		if(kmutex_lock_cancellable(&mutex_1))
		{
			dbgq(DBG_TESTPASS,"\nTESTCASE - The killed Process '");
			getprocname();
			dbgq(DBG_TESTPASS,"' with PID %d enters its cancellation routine !!!!\n",curproc->p_pid);			
			kmutex_unlock(&mutex_2);
			dbgq(DBG_TESTPASS,"TESTCASE - Unlocked Mutex 2 and exiting\n!!!");			
			kthread_exit((void *)0);
		}

		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to lock Mutex 1: SUCCESS!!!!\n",curproc->p_pid);

		kmutex_unlock(&mutex_1);

		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to unlock Mutex 1: SUCCESS!!!!\n",curproc->p_pid);

		kmutex_unlock(&mutex_2);

		dbgq(DBG_TESTPASS,"TESTCASE - Process '");
		getprocname();
		dbgq(DBG_TESTPASS,"' with PID %d attempted to unlock Mutex 2: SUCCESS!!!!\n",curproc->p_pid);

		return NULL;
}

static void *Orphaned_func(int arg1, void *arg2)
{
		reparent++;
		dbgq(DBG_TESTPASS,"TESTCASE - The orphaned process with PID %d exists until it is cleaned up by the INIT PROCESS!!!\n", curproc->p_pid);
		sched_sleep_on(&curproc->p_wait);
		return NULL;
}

static void *Reparenting_func(int arg1, void *arg2)
{
		proc_t *p;
		kthread_t *thr;

		print_stats(0, NULL);

		p = proc_create("orphaned_proc_1");
		thr = kthread_create(p, Orphaned_func, 0, NULL);
		sched_make_runnable(thr);

		dbgq(DBG_TESTPASS,"TESTCASE - CREATE: The Process '");
		get_child_name(p->p_comm);
		dbgq(DBG_TESTPASS,"' with PID %d created successfully\n",p->p_pid);

		dbgq(DBG_TESTPASS,"TESTCASE - Thread for Process '");
		get_child_name(p->p_comm);
		dbgq(DBG_TESTPASS,"' created successfully\n");

		p = proc_create("orphaned_proc_2");
		thr = kthread_create(p, Orphaned_func, 0, NULL);
		sched_make_runnable(thr);

		dbgq(DBG_TESTPASS,"TESTCASE - CREATE: The Process '");
		get_child_name(p->p_comm);
		dbgq(DBG_TESTPASS,"' with PID %d created successfully\n",p->p_pid);

		dbgq(DBG_TESTPASS,"TESTCASE - Thread for Process '");
		get_child_name(p->p_comm);
		dbgq(DBG_TESTPASS,"' created successfully\n");

		dbgq(DBG_TESTPASS,"\nTESTCASE - The Parent Process exits calling do_exit() without waiting for its children to terminate!!!\n");
		do_exit(0);
		return NULL;
}

static void *cond_wait(ktqueue_t *q, kmutex_t *mtx)
{
	dbgq(DBG_TESTPASS, "TESTCASE - The process with PID %d enters conditional wait queue by unlocking its mutex!!!!\n",curproc->p_pid);
	kmutex_unlock(mtx);
	sched_sleep_on(q);
	kmutex_lock(mtx);
	dbgq(DBG_TESTPASS, "\nTESTCASE - The process with PID %d returns from conditional wait queue by locking the mutex it unlocked previously!!!!\n",curproc->p_pid);
	return NULL;
}

static void *cond_broadcast(ktqueue_t *q)
{
	sched_broadcast_on(q);
	return NULL;
}

static void *barrier(int arg1, void *arg2)
{
	int local_flag;
	dbgq(DBG_TESTPASS, "TESTCASE - The process with PID %d enters barrier function and locks a mutex!!!!\n",curproc->p_pid);
	kmutex_lock(&mutex_1);
	count++;
	dbgq(DBG_TESTPASS, "TESTCASE - Number of processes entered the barrier is %d !!!!\n",count);
	if(count < TESTCASE_5)
	{
		local_flag = global_flag;
		while(local_flag == global_flag)
		{
			cond_wait(&barrier_queue, &mutex_1);
		}
	}
	else
	{
		count = 0;
		global_flag++;
		dbgq(DBG_TESTPASS, "\nTESTCASE - Required number of processes entered the barrier\n");
		dbgq(DBG_TESTPASS, "TESTCASE - The process with PID %d broadcasts this info to all processes waiting in the conditional queue!!!!\n",curproc->p_pid);		
		cond_broadcast(&barrier_queue);
	}
	kmutex_unlock(&mutex_1);
	return NULL;
}

static void *producer_func(int arg1, void *arg2)
{
	int i;
	c++;
	for(i=0; i<rate_p; i++)
	{
		if(value > 25)
			break;
			
		kmutex_lock(&mutex_2);
		while(empty <= 0)
		{
			dbgq(DBG_TESTPASS,"\nTESTCASE - No empty slots in the buffer!!! Producer waits until an empty space is available\n");
			cond_wait(&pc_queue, &mutex_2);
		}
		empty = empty - 1;
		kmutex_unlock(&mutex_2);

		buffer[next_in] = value;
		dbgq(DBG_TESTPASS, "TESTCASE - Producer placed the item %d into the %d slot of buffer\n",buffer[next_in],next_in);
		next_in = next_in+1;
		value = value+1;
		if(next_in == BUFSIZE)
			next_in = 0;

		kmutex_lock(&mutex_2);
		occuppied = occuppied + 1;
		cond_broadcast(&pc_queue);
		kmutex_unlock(&mutex_2);
	}
	sched_make_runnable(curthr);
	if(c%2 == 0)
		rate_c = 1;
	else
		rate_c = 5;
		
	dbgq(DBG_TESTPASS, "TESTCASE - Context switches from producer to consumer\n");	
	sched_switch();
	
	if(value < 26)
		producer_func(0, NULL);
	else
	{
		value = 1;
		next_in = 0;
		rate_c = 3;
		c=0;
	}

	return NULL;
}

static void *consumer_func(int arg1, void *arg2)
{
	char item;
	d++;
	int i;
	for(i=0; i<rate_c; i++)
	{
		if(item >= 25)
			break;
							
		kmutex_lock(&mutex_2);
		while(occuppied <= 0)
		{
			dbgq(DBG_TESTPASS, "\nTESTCASE - No more items in the buffer... Consumer waits until a new item is placed!!!\n");
			cond_wait(&pc_queue, &mutex_2);
		}
		occuppied = occuppied - 1;
		kmutex_unlock(&mutex_2);

		item = buffer[next_out];
		dbgq(DBG_TESTPASS, "TESTCASE - Consumer consumed the item %d from the %d slot of buffer\n",item, next_out);
		next_out = next_out + 1;
		if(next_out == BUFSIZE)
			next_out = 0;

		kmutex_lock(&mutex_2);
		empty = empty + 1;
		cond_broadcast(&pc_queue);
		kmutex_unlock(&mutex_2);
	}
	sched_make_runnable(curthr);
	if(d%2 == 0)
		rate_p = 9;
	else
		rate_p = 1;
		
	dbgq(DBG_TESTPASS, "TESTCASE - Context switches from consumer to producer\n");	
	sched_switch();
	
	if(item >= 25)
	{
		item = 0;
		next_out = 0;
		rate_p = 3;
		d = 0;
	}
	else
		consumer_func(0, NULL);	
			
	return NULL;
}


int do_testcase_1(kshell_t *ksh, int argc, char **argv)
{
	int i;
	proc_t *test_process;
	kthread_t *test_thread;

		for(i=0; i<TESTCASE_1; i++)
		{
			char name[20];
			strcpy(name,"Test_process:");
			if(i>=9)
			{
				sprintf(&name[13],"%d",(i+1)/10);
				sprintf(&name[14],"%d",(i+1)%10);
				name[15] = '\0';
			}
			else
			{
				sprintf(&name[13],"%d",(i+1));
				name[14] = '\0';
			}
			test_process = proc_create(name);
			test_thread = kthread_create(test_process, print_stats, 0, NULL);
			sched_make_runnable(test_thread);
		}

	print_rows();
	dbgq(DBG_TESTPASS,"|   TESTCASE 1: CREATING BUNCH OF PROCESSES AND THREADS AND TERMINATING THEM   |");
	print_rows();

	for(i=0; i<TESTCASE_1; i++)
	{
		child = do_waitpid(-1, 0, &status);
		dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	}
	print_rows();
	dbgq(DBG_TESTPASS,"|				END OF TESTCASE 1: PASSED		       |");
	print_rows();

	return 0;
}

int do_testcase_2(kshell_t *ksh, int argc, char **argv)
{
	int i;
	proc_t *mutex_proc1;
	kthread_t *mutex_thread1;
	kmutex_init(&mutex_1);
	kmutex_init(&mutex_2);

	for(i=0; i<TESTCASE_2; i++)
	{
		mutex_proc1 = proc_create("Kmutex_Locking_Proc");
		mutex_thread1 = kthread_create(mutex_proc1, shared_data_proc1, 0, NULL);
		sched_make_runnable(mutex_thread1);
	}

	print_rows();
	dbgq(DBG_TESTPASS,"|	TESTCASE 2: DEMONSTARTE SYNCHRONIZATION PRIMITIVES WORK");
	print_rows();

	sched_make_runnable(curthr);
	sched_switch();

	for(i=0; i<TESTCASE_2; i++)
	{
		shared_data_proc2();
		child = do_waitpid(-1, 0, &status);
		dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	}

	print_rows();
	dbgq(DBG_TESTPASS,"|				END OF TESTCASE 2: PASSED		       |");
	print_rows();

	return 0;
}

int do_testcase_3(kshell_t *ksh, int argc, char **argv)
{
	pid_t deadlock_proc_1, deadlock_proc_2, child;
	int i;
	proc_t *mutex_proc1, *mutex_proc2;
	kthread_t *mutex_thread1, *mutex_thread2;

	mutex_proc1 = proc_create("Create_Deadlock_proc_1");
	deadlock_proc_1 = mutex_proc1->p_pid;
	mutex_thread1 = kthread_create(mutex_proc1, deadlock_proc1, 0, NULL);
	sched_make_runnable(mutex_thread1);

	mutex_proc1 = proc_create("Create_Deadlock_proc_2");
	deadlock_proc_2 = mutex_proc1->p_pid;
	mutex_thread1 = kthread_create(mutex_proc1, deadlock_proc2, 0, NULL);
	sched_make_runnable(mutex_thread1);

	print_rows();
	dbgq(DBG_TESTPASS,"|	TESTCASE 3: CREATE CIRCULAR WAIT AND CAUSE DEADLOCK SCENARIO");
	print_rows();

	sched_make_runnable(curthr);
	sched_switch();

	sched_make_runnable(curthr);
	sched_switch();

	dbgq(DBG_TESTPASS,"\n\tTESTCASE - DEADLOCK OCCURED!!! OS HANGS FOR FEW SECONDS\n\n");

	while(i<500000000)
	{
		i++;
	}

	dbgq(DBG_TESTPASS,"TESTCASE - Killing the Deadlocked Process by calling PROC_KILL()\n");

    proc_t *kill_process;

	list_iterate_begin(&curproc->p_children, kill_process, proc_t, p_child_link)
	{
		if(kill_process->p_pid == deadlock_proc_1 || kill_process->p_pid == deadlock_proc_2)
			proc_kill(kill_process, 0);
	}list_iterate_end();

	child = do_waitpid(deadlock_proc_2, 0 ,&status);
		dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);

	child = do_waitpid(deadlock_proc_1, 0 ,&status);
		dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);

	print_rows();
	dbgq(DBG_TESTPASS,"|				END OF TESTCASE 3: PASSED		       |");
	print_rows();

	return 0;
}

int do_testcase_4(kshell_t *ksh, int argc, char **argv)
{
	print_rows();
	dbgq(DBG_TESTPASS,"|   TESTCASE 4: REPARENTING CHILD PROCESSES OF EXITED PROCESS TO INIT PROCESS");
	print_rows();

	proc_t *test_process;
	kthread_t *test_thread;

	test_process = proc_create("Parent_process");
	test_thread = kthread_create(test_process, Reparenting_func, 0, NULL);
	sched_make_runnable(test_thread);

	child = do_waitpid(-1, 0, &status);
	dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);

	print_rows();
	dbgq(DBG_TESTPASS,"|				END OF TESTCASE 4: PASSED		       |");
	print_rows();

	return 0;
}

int do_testcase_5(kshell_t *ksh, int argc, char **argv)
{
	kmutex_init(&mutex_1);
	sched_queue_init(&barrier_queue);
	int i;

	proc_t *test_process;
	kthread_t *test_thread;

	for(i=0; i<TESTCASE_5; i++)
	{
		char name[20];
		strcpy(name,"Barrier_Proc_");
		sprintf(&name[13],"%d",(i+1));
		name[14] = '\0';
		test_process = proc_create(name);
		test_thread = kthread_create(test_process, barrier, 0, NULL);
		sched_make_runnable(test_thread);
	}
	dbgq(DBG_TESTPASS, "TESTCASE - Inorder for the processes to proceed from Barrier function the number of process that entered must be %d\n", TESTCASE_5);
	print_rows();
	dbgq(DBG_TESTPASS,"|   		TESTCASE 5: DEMONSTRATE SOLUTION FOR BARRIER PROBLEM ");
	print_rows();

	for(i=0; i<TESTCASE_5; i++)
	{
		child = do_waitpid(-1, 0 ,&status);
		dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	}

	print_rows();
	dbgq(DBG_TESTPASS,"|				END OF TESTCASE 5: PASSED		       |");
	print_rows();

	return 0;
}

int do_testcase_6(kshell_t *ksh, int argc, char **argv)
{
	pid_t producer_pid, consumer_pid;
	kmutex_init(&mutex_2);
	sched_queue_init(&pc_queue);

	proc_t *producer_proc, *consumer_proc;
	kthread_t *producer_thr, *consumer_thr;

	producer_proc = proc_create("Producer");
	producer_pid = producer_proc->p_pid;
	producer_thr = kthread_create(producer_proc, producer_func, 0, NULL);
	sched_make_runnable(producer_thr);

	consumer_proc = proc_create("Consumer");
	consumer_pid = consumer_proc->p_pid;
	consumer_thr = kthread_create(consumer_proc, consumer_func, 0, NULL);
	sched_make_runnable(consumer_thr);

	print_rows();
	dbgq(DBG_TESTPASS,"|   		TESTCASE 6: DEMONSTRATE PRODUCER CONSUMER PROBLEM ");
	print_rows();

	dbgq(DBG_TESTPASS, "TESTCASE - Producer process with PID %d created successfully!!!\n",producer_pid);
	dbgq(DBG_TESTPASS, "TESTCASE - Consumer process with PID %d created successfully!!!\n",consumer_pid);

	child = do_waitpid(producer_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);

	child = do_waitpid(consumer_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);

	print_rows();
	dbgq(DBG_TESTPASS,"|				END OF TESTCASE 6: PASSED		       |");
	print_rows();

	return 0;
}

static void *kshell_func(int arg1, void *arg2)
{
	print_stats(0, NULL);
	kshell_add_command("test_1", do_testcase_1, "invoke do_testcase_1()...");
	kshell_add_command("test_2", do_testcase_2, "invoke do_testcase_2()...");
	kshell_add_command("test_3", do_testcase_3, "invoke do_testcase_3()...");
	kshell_add_command("test_4", do_testcase_4, "invoke do_testcase_4()...");
	kshell_add_command("test_5", do_testcase_5, "invoke do_testcase_5()...");
    kshell_add_command("test_6", do_testcase_6, "invoke do_testcase_6()...");

    kshell = kshell_create(0);
    if (NULL == kshell) panic("init: Couldn't create kernel shell\n");
	print_rows();
	if(drivers)
		kprintf(kshell,"|TESTCASE 7: DEMONSTRATE TESTCASES USING KSHELL\n");
	dbgq(DBG_TESTPASS,"|   		TESTCASE 7: DEMONSTRATE TESTCASES USING KSHELL ");
	print_rows();    
    while (kshell_execute_next(kshell));
	drivers = 0;
    kshell_destroy(kshell);

    return NULL;
}

static void do_testcase_7()
{
	proc_t *kshell_proc;
	kthread_t *kshell_thr;
	pid_t kshell_pid;

	kshell_proc = proc_create("kshell_proc");
	kshell_pid = kshell_proc->p_pid;
	kshell_thr = kthread_create(kshell_proc, kshell_func, 0, NULL);
	sched_make_runnable(kshell_thr);

	child = do_waitpid(kshell_pid, 0 ,&status);
	dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);

    

	print_rows();
	dbgq(DBG_TESTPASS,"|				END OF TESTCASE 7: PASSED		       |");
	print_rows();

}



/**
 * The init thread's function changes depending on how far along your Weenix is
 * developed. Before VM/FI, you'll probably just want to have this run whatever
 * tests you've written (possibly in a new process). After VM/FI, you'll just
 * exec "/bin/init".
 *
 * Both arguments are unused.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
static void *
initproc_run(int arg1, void *arg2)
{

	/*-----------------------------------Testcase 1:----------------------------------------*/

	do_testcase_1(kshell, 0 , NULL);

	/*-----------------------------------Testcase 2:----------------------------------------*/

	do_testcase_2(kshell, 0 , NULL);

	/*-----------------------------------Testcase 3:----------------------------------------*/

	do_testcase_3(kshell, 0 , NULL);

	/*-----------------------------------Testcase 4:----------------------------------------*/

	do_testcase_4(kshell, 0 , NULL);

	/*-----------------------------------Testcase 5:----------------------------------------*/

	do_testcase_5(kshell, 0 , NULL);

	/*-----------------------------------Testcase 6:----------------------------------------*/

	do_testcase_6(kshell, 0 , NULL);
	
	/*-----------------------------------Testcase 7:----------------------------------------*/

    #ifdef __DRIVERS__

	drivers = 1;
	do_testcase_7();

    #endif /* __DRIVERS__ */

	int i;
	proc_t *wakeup_process;
    kthread_t *wakeup_thread;
	
	list_iterate_begin(&curproc->p_children, wakeup_process, proc_t, p_child_link)
	{
		list_iterate_begin(&wakeup_process->p_threads, wakeup_thread, kthread_t, kt_plink)
		{
			if(wakeup_thread->kt_state == KT_SLEEP)
			{
				dbgq(DBG_TESTPASS,"TESTCASE - The INIT process wakes up the sleeping step child with PID %d\n",wakeup_process->p_pid);
				sched_wakeup_on(&wakeup_process->p_wait);	
			}		
		}list_iterate_end();	
	}list_iterate_end();	
	
	dbgq(DBG_TESTPASS,"TESTCASE - The INIT process performs a final cleanup by killing all of its children and STEP CHILDREN!!!\n");
	proc_kill_all();

	for(i=0; i<reparent; i++)
	{
		child = do_waitpid(-1, 0, &status);
		dbgq(DBG_TESTPASS, "TESTCASE - Traces of zombie process with PID %d is removed by parent process with PID %d!!!!\n",child, curproc->p_pid);
	}
   return NULL;
}

/**
 * Clears all interrupts and halts, meaning that we will never run
 * again.
 */
static void
hard_shutdown()
{
#ifdef __DRIVERS__
        vt_print_shutdown();
#endif
        __asm__ volatile("cli; hlt");
}
