/*
 *  FILE: vfs_syscall.c
 *  AUTH: mcc | jal
 *  DESC:
 *  DATE: Wed Apr  8 02:46:19 1998
 *  $Id: vfs_syscall.c,v 1.1 2012/10/10 20:06:46 william Exp $
 */

#include "kernel.h"
#include "errno.h"
#include "globals.h"
#include "fs/vfs.h"
#include "fs/file.h"
#include "fs/vnode.h"
#include "fs/vfs_syscall.h"
#include "fs/open.h"
#include "fs/fcntl.h"
#include "fs/lseek.h"
#include "mm/kmalloc.h"
#include "util/string.h"
#include "util/printf.h"
#include "fs/stat.h"
#include "util/debug.h"

#define ACCESSMODE 0x003
#define STATUSFLAG 0x700

void print_err_message(char *func_name, int err)
{
	switch(err)
    {
		case 2:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - No such file or directory!!!\n", func_name);
				break;

		case 9:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - Bad file number!!!\n", func_name);
				break;

		case 17:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - File or directory exists!!!\n", func_name);
				break;

		case 20:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - Not a directory!!!\n", func_name);
				break;

		case 21:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - Is a directory!!!\n", func_name);
				break;

		case 22:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - Invalid argument!!!\n", func_name);
				break;

		case 24:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - Too many open files!!!\n", func_name);
				break;
				
		case 28:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - No space left on device!!!\n", func_name);
				break;

		case 36:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - File name too long!!!\n", func_name);
				break;

		case 39:
				dbgq(DBG_TESTPASS, "RETURN ERR MSG: From function %s - Directory not empty!!!\n", func_name);
				break;
	}				
}

/* To read a file:
 *      o fget(fd)
 *      o call its virtual read f_op
 *      o update f_pos
 *      o fput() it
 *      o return the number of bytes read, or an error
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd is not a valid file descriptor or is not open for reading.
 *      o EISDIR
 *        fd refers to a directory.
 *
 * In all cases, be sure you do not leak file refcounts by returning before
 * you fput() a file that you fget()'ed.
 */
int
do_read(int fd, void *buf, size_t nbytes)
{
        if(fd < 0 || fd >= NFILES)
		{
			print_err_message("do_read", EBADF);
			return -EBADF;
		}
		        
        file_t *file_to_read = fget(fd);
		
		if(file_to_read == NULL)
		{
			print_err_message("do_read", EBADF);
			return -EBADF;
		}
		
		if(S_ISDIR(file_to_read->f_vnode->vn_mode))
		{
			fput(file_to_read);
			print_err_message("do_read", EISDIR);
			return -EISDIR;
		}
		
        if(((file_to_read->f_mode & ACCESSMODE) != (FMODE_WRITE|FMODE_READ)) && ((file_to_read->f_mode & ACCESSMODE) != FMODE_READ))
        {
			fput(file_to_read);
			print_err_message("do_read", EBADF);
			return -EBADF;
		}
		int bytes_read = file_to_read->f_vnode->vn_ops->read(file_to_read->f_vnode, file_to_read->f_pos, buf, nbytes);
		file_to_read->f_pos = file_to_read->f_pos + bytes_read;

		fput(file_to_read);
        return bytes_read;
}

/* Very similar to do_read.  Check f_mode to be sure the file is writable.  If
 * f_mode & FMODE_APPEND, do_lseek() to the end of the file, call the write
 * f_op, and fput the file.  As always, be mindful of refcount leaks.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd is not a valid file descriptor or is not open for writing.
 */
int
do_write(int fd, const void *buf, size_t nbytes)
{
        if(fd < 0 || fd >= NFILES)
		{
			print_err_message("do_write", EBADF);
			return -EBADF;
		}

        file_t *f = fget(fd);
        off_t offset;
        int bytes_written;
        
		if(f == NULL)
		{
			print_err_message("do_write", EBADF);
			return -EBADF;
		}
		        
        if(((f->f_mode & ACCESSMODE) == (FMODE_WRITE|FMODE_READ)) || ((f->f_mode & ACCESSMODE) == FMODE_WRITE))
        {
			if((f->f_mode & FMODE_APPEND) == FMODE_APPEND)
			{
				f->f_pos = do_lseek(fd, 0, SEEK_END);
			}
			bytes_written = f->f_vnode->vn_ops->write(f->f_vnode, f->f_pos, buf, nbytes);
			f->f_pos = f->f_pos + bytes_written;
			KASSERT((S_ISCHR(f->f_vnode->vn_mode)) || (S_ISBLK(f->f_vnode->vn_mode)) || ((S_ISREG(f->f_vnode->vn_mode)) && (f->f_pos <= f->f_vnode->vn_len)));		
		}
		else
		{
			fput(f);
			print_err_message("do_write", EBADF);
			return -EBADF;
		}
		
		fput(f);
		return bytes_written;
}

/*
 * Zero curproc->p_files[fd], and fput() the file. Return 0 on success
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd isn't a valid open file descriptor.
 */
int
do_close(int fd)
{
        if(fd < 0 || fd >= NFILES)
		{
			print_err_message("do_close", EBADF);
			return -EBADF;
		}

		if(fget(fd) == NULL)
		{
			print_err_message("do_close", EBADF);
			return -EBADF;
		}
		fput(curproc->p_files[fd]);
		fput(curproc->p_files[fd]);	
		curproc->p_files[fd] = NULL;
		
        return 0;
}

/* To dup a file:
 *      o fget(fd) to up fd's refcount
 *      o get_empty_fd()
 *      o point the new fd to the same file_t* as the given fd
 *      o return the new file descriptor
 *
 * Don't fput() the fd unless something goes wrong.  Since we are creating
 * another reference to the file_t*, we want to up the refcount.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd isn't an open file descriptor.
 *      o EMFILE
 *        The process already has the maximum number of file descriptors open
 *        and tried to open a new one.
 */
int
do_dup(int fd)
{
        if(fd < 0 || fd >= NFILES)
		{
			print_err_message("do_dup", EBADF);
			return -EBADF;
		}

        file_t *dup_file;
        int nextempty_fd;
        dup_file = fget(fd);
        if(dup_file == NULL)
        {
			print_err_message("do_dup", EBADF);
			return -EBADF;
		}
		
		nextempty_fd = get_empty_fd(curproc);
        if(nextempty_fd == -EMFILE)
        {
			fput(dup_file);
			print_err_message("do_dup", EMFILE);
			return -EMFILE;
		}
		curproc->p_files[nextempty_fd] = dup_file;
					
        return nextempty_fd;
}

/* Same as do_dup, but insted of using get_empty_fd() to get the new fd,
 * they give it to us in 'nfd'.  If nfd is in use (and not the same as ofd)
 * do_close() it first.  Then return the new file descriptor.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        ofd isn't an open file descriptor, or nfd is out of the allowed
 *        range for file descriptors.
 */
int
do_dup2(int ofd, int nfd)
{
        if(ofd < 0 || ofd >= NFILES)
		{
			print_err_message("do_dup2", EBADF);
			return -EBADF;
		}

        if(nfd < 0 || nfd >= NFILES)
		{
			print_err_message("do_dup2", EBADF);
			return -EBADF;
		}
        file_t *dup2_file;
        
        dup2_file = fget(ofd);
   
        if(dup2_file == NULL)
        {
			print_err_message("do_dup2", EBADF);
			return -EBADF;
		}
		
        if(ofd == nfd)
        {
			fput(dup2_file);
			return nfd;
		}
		
        if(nfd < 0 || nfd >= NFILES)
        {
			fput(dup2_file);
			print_err_message("do_dup2", EBADF);
			return -EBADF;
		}
		file_t *new_fd_file = fget(nfd);
		if(new_fd_file != NULL)
		{
			fput(new_fd_file);
			do_close(nfd);
		}					
		
		curproc->p_files[nfd] = dup2_file;      
        return nfd;
}

/*
 * This routine creates a special file of the type specified by 'mode' at
 * the location specified by 'path'. 'mode' should be one of S_IFCHR or
 * S_IFBLK (you might note that mknod(2) normally allows one to create
 * regular files as well-- for simplicity this is not the case in Weenix).
 * 'devid', as you might expect, is the device identifier of the device
 * that the new special file should represent.
 *
 * You might use a combination of dir_namev, lookup, and the fs-specific
 * mknod (that is, the containing directory's 'mknod' vnode operation).
 * Return the result of the fs-specific mknod, or an error.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EINVAL
 *        mode requested creation of something other than a device special
 *        file.
 *      o EEXIST
 *        path already exists.
 *      o ENOENT
 *        A directory component in path does not exist.
 *      o ENOTDIR
 *        A component used as a directory in path is not, in fact, a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 */
int
do_mknod(const char *path, int mode, unsigned devid)
{
        if(strlen(path) < 1)
        {
			print_err_message("do_mknod", EINVAL);
			return -EINVAL;
		}
		 
        if(strlen(path) > MAXPATHLEN)
        {
			print_err_message("do_mknod", ENAMETOOLONG);
			return -ENAMETOOLONG;
		}
			
        size_t special_file_namelen;
        const char *special_file_name;
        vnode_t *special_file_vnode;
        int return_code;
        
        if(mode != S_IFCHR && mode != S_IFBLK)
        {
			print_err_message("do_mknod", EINVAL);
			return_code = -EINVAL;
		}
			
		return_code = dir_namev(path, &special_file_namelen, &special_file_name, NULL, &special_file_vnode);
		
        if(return_code == -ENAMETOOLONG)
        {
			print_err_message("do_mknod", ENAMETOOLONG);
			return return_code;
		}
			
        if(return_code == -ENOENT)
		{
			print_err_message("do_mknod", ENOENT);
			return return_code;
		}
			
        if(return_code == -ENOTDIR)
		{
			print_err_message("do_mknod", ENOTDIR);
			return return_code;
		}
								
		vput(special_file_vnode);	
			
        return_code = lookup(special_file_vnode, special_file_name, special_file_namelen, &special_file_vnode);					
        
        if(return_code == 0)
        {
			vput(special_file_vnode);
			print_err_message("do_mknod", EEXIST);
			return -EEXIST;
		}
		
        if(return_code == -ENOENT)
        {
			KASSERT(NULL != special_file_vnode->vn_ops->mknod);
			return_code = special_file_vnode->vn_ops->mknod(special_file_vnode, special_file_name, special_file_namelen, mode, devid);
			
			if(return_code == -ENOSPC)
			{
				print_err_message("do_mknod", ENOSPC);
				return return_code;
			}
			
			return 0;
		}
					
        return -1;
}

/* Use dir_namev() to find the vnode of the dir we want to make the new
 * directory in.  Then use lookup() to make sure it doesn't already exist.
 * Finally call the dir's mkdir vn_ops. Return what it returns.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EEXIST
 *        path already exists.
 *      o ENOENT
 *        A directory component in path does not exist.
 *      o ENOTDIR
 *        A component used as a directory in path is not, in fact, a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 */
int
do_mkdir(const char *path)
{
        if(strlen(path) < 1)
        {
			print_err_message("do_mkdir", EINVAL);
			return -EINVAL;
		}
		 
        if(strlen(path) > MAXPATHLEN)
        {
			print_err_message("do_mkdir", ENAMETOOLONG);
			return -ENAMETOOLONG;
		}	
	
        size_t dir_namelen;
        const char *dir_name;
        vnode_t *dir_vnode;
        int return_code;
        
        return_code = dir_namev(path, &dir_namelen, &dir_name, NULL, &dir_vnode);
        
        if(return_code == -ENAMETOOLONG)
        {
			print_err_message("do_mkdir", ENAMETOOLONG);
			return return_code;
		}
			
        if(return_code == -ENOENT)
		{
			print_err_message("do_mkdir", ENOENT);
			return return_code;
		}
			
        if(return_code == -ENOTDIR)
		{
			print_err_message("do_mkdir", ENOTDIR);
			return return_code;
		}
		
		vput(dir_vnode);	
        
        return_code = lookup(dir_vnode, dir_name, dir_namelen, &dir_vnode);
        
        if(return_code == 0)
		{
			vput(dir_vnode);
			print_err_message("do_mkdir", EEXIST);
			return -EEXIST;
		}   
        if(return_code == -ENOENT)
        {
			KASSERT(NULL != dir_vnode->vn_ops->mkdir);		
			return_code = dir_vnode->vn_ops->mkdir(dir_vnode, dir_name, dir_namelen);
			if(return_code == -ENOSPC)			
			{
				print_err_message("do_mkdir", ENOSPC);
				return return_code;
			}			
			return 0;
		}
        
        return -1;
}

/* Use dir_namev() to find the vnode of the directory containing the dir to be
 * removed. Then call the containing dir's rmdir v_op.  The rmdir v_op will
 * return an error if the dir to be removed does not exist or is not empty, so
 * you don't need to worry about that here. Return the value of the v_op,
 * or an error.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EINVAL
 *        path has "." as its final component.
 *      o ENOTEMPTY
 *        path has ".." as its final component.
 *      o ENOENT
 *        A directory component in path does not exist.
 *      o ENOTDIR
 *        A component used as a directory in path is not, in fact, a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 */
int
do_rmdir(const char *path)
{
        if(strlen(path) < 1)
        {
			print_err_message("do_rmdir", EINVAL);
			return -EINVAL;
		}
		 
        if(strlen(path) > MAXPATHLEN)
        {
			print_err_message("do_rmdir", ENAMETOOLONG);
			return -ENAMETOOLONG;
		}	
	
        size_t rem_dir_namelen;
        const char *rem_dir_name;
        vnode_t *rem_dir_vnode;
        int return_code;
        
        return_code = dir_namev(path, &rem_dir_namelen, &rem_dir_name, NULL, &rem_dir_vnode);
        
        if(return_code == -ENAMETOOLONG)
        {
			print_err_message("do_rmdir", ENAMETOOLONG);
			return return_code;
		}
			
        if(return_code == -ENOENT)
		{
			print_err_message("do_rmdir", ENOENT);
			return return_code;
		}
			
        if(return_code == -ENOTDIR)
		{
			print_err_message("do_rmdir", ENOTDIR);
			return return_code;
		}
		
		if(strcmp(rem_dir_name, ".") == 0)
		{
			vput(rem_dir_vnode);
			print_err_message("do_rmdir", EINVAL);
			return -EINVAL;
		}
		
		if(strcmp(rem_dir_name, "..") == 0)
		{
			vput(rem_dir_vnode);
			print_err_message("do_rmdir", ENOTEMPTY);
			return -ENOTEMPTY;
		}
		
		KASSERT(NULL != rem_dir_vnode->vn_ops->rmdir);      
		return_code = rem_dir_vnode->vn_ops->rmdir(rem_dir_vnode, rem_dir_name, rem_dir_namelen);
        vput(rem_dir_vnode);
        
        if(return_code == -ENOENT)
		{
			print_err_message("do_rmdir", ENOENT);
			return return_code;
		}
		
        if(return_code == -ENOTDIR)
		{
			print_err_message("do_rmdir", ENOTDIR);
			return return_code;
		}
		
        if(return_code == -ENOTEMPTY)
		{
			print_err_message("do_rmdir", ENOTEMPTY);
			return return_code;
		}		
		
        return return_code;
}

/*
 * Same as do_rmdir, but for files.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EISDIR
 *        path refers to a directory.
 *      o ENOENT
 *        A component in path does not exist.
 *      o ENOTDIR
 *        A component used as a directory in path is not, in fact, a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 */
int
do_unlink(const char *path)
{
        if(strlen(path) < 1)
        {
			print_err_message("do_unlink", EINVAL);
			return -EINVAL;
		}
		 
        if(strlen(path) > MAXPATHLEN)
        {
			print_err_message("do_unlink", ENAMETOOLONG);
			return -ENAMETOOLONG;
		}	
	
        size_t rem_dir_namelen;
        const char *rem_dir_name;
        vnode_t *rem_dir_vnode, *temp_vnode;
        int return_code;
        
        return_code = dir_namev(path, &rem_dir_namelen, &rem_dir_name, NULL, &rem_dir_vnode);

        if(return_code == -ENAMETOOLONG)
        {
			print_err_message("do_unlink", ENAMETOOLONG);
			return return_code;
		}
			
        if(return_code == -ENOENT)
		{
			print_err_message("do_unlink", ENOENT);
			return return_code;
		}
			
        if(return_code == -ENOTDIR)
		{
			print_err_message("do_unlink", ENOTDIR);
			return return_code;
		}
			
		return_code = lookup(rem_dir_vnode, rem_dir_name, rem_dir_namelen, &temp_vnode);

		if(return_code == -ENOENT)
		{
			vput(rem_dir_vnode);
			print_err_message("do_unlink", ENOENT);
			return -ENOENT;
		}
        if (S_ISDIR(temp_vnode->vn_mode))
        {
			vput(temp_vnode);
			vput(rem_dir_vnode);
			print_err_message("do_unlink", EISDIR);
            return -EISDIR;
        }
		
		if(return_code == 0)
		{
			KASSERT(NULL != rem_dir_vnode->vn_ops->unlink);
			return_code = rem_dir_vnode->vn_ops->unlink(rem_dir_vnode,rem_dir_name,rem_dir_namelen);
			vput(temp_vnode);
			vput(rem_dir_vnode);
			return return_code;			
		}
		return -1;
}

/* To link:
 *      o open_namev(from)
 *      o dir_namev(to)
 *      o call the destination dir's (to) link vn_ops.
 *      o return the result of link, or an error
 *
 * Remember to vput the vnodes returned from open_namev and dir_namev.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EEXIST
 *        to already exists.
 *      o ENOENT
 *        A directory component in from or to does not exist.
 *      o ENOTDIR
 *        A component used as a directory in from or to is not, in fact, a
 *        directory.
 *      o ENAMETOOLONG
 *        A component of from or to was too long.
 */
int
do_link(const char *from, const char *to)
{
        if((strlen(from) < 1) || (strlen(to) < 1))
        {
			print_err_message("do_link", EINVAL);
			return -EINVAL;
		}
		 
        if((strlen(from) > MAXPATHLEN) || (strlen(to) > MAXPATHLEN))
        {
			print_err_message("do_link", ENAMETOOLONG);
			return -ENAMETOOLONG;
		}
			
        size_t dirlen_to;
        vnode_t *dirnode_to, *dirnode_from;
        const char *dirname_to;
        int return_code;
        
        return_code = open_namev(from, O_RDONLY, &dirnode_from, NULL);
        
        if(return_code == -ENAMETOOLONG)
        {
			print_err_message("do_link", ENAMETOOLONG);
			return return_code;
		}
			
        if(return_code == -ENOENT)
		{
			print_err_message("do_link", ENOENT);
			return return_code;
		}
			
        if(return_code == -ENOTDIR)
		{
			print_err_message("do_link", ENOTDIR);
			return return_code;
		}
		
		vput(dirnode_from);
		
		return_code = dir_namev(to, &dirlen_to, &dirname_to, NULL, &dirnode_to);
		
        if(return_code == -ENAMETOOLONG)
        {
			print_err_message("do_link", ENAMETOOLONG);
			return return_code;
		}
			
        if(return_code == -ENOENT)
		{
			print_err_message("do_link", ENOENT);
			return return_code;
		}
			
        if(return_code == -ENOTDIR)
		{
			print_err_message("do_link", ENOTDIR);
			return return_code;
		}
		
		vput(dirnode_to);
		
		return_code = lookup(dirnode_to, dirname_to, dirlen_to, &dirnode_to);
		
		if(return_code == 0)
		{
			vput(dirnode_to);
			print_err_message("do_link", EEXIST);
			return -EEXIST;
		}
		
		if(return_code == -ENOENT)
		{
			return_code = dirnode_to->vn_ops->link(dirnode_from, dirnode_to, dirname_to, dirlen_to);
			if(return_code == -ENOSPC)			
			{
				print_err_message("do_link", ENOSPC);
				return return_code;
			}		
			return 0;			        
        }
        return -1;
}

/*      o link newname to oldname
 *      o unlink oldname
 *      o return the value of unlink, or an error
 *
 * Note that this does not provide the same behavior as the
 * Linux system call (if unlink fails then two links to the
 * file could exist).
 */
int
do_rename(const char *oldname, const char *newname)
{
        if((strlen(oldname) < 1) || (strlen(newname) < 1))
        {
			print_err_message("do_rename", EINVAL);
			return -EINVAL;
		}
		 
        if((strlen(oldname) > MAXPATHLEN) || (strlen(newname) > MAXPATHLEN))
        {
			print_err_message("do_rename", ENAMETOOLONG);
			return -ENAMETOOLONG;
		}
        int return_code;
        return_code = do_link(oldname, newname);
        return_code = do_unlink(oldname);
        
        return return_code;
}

/* Make the named directory the current process's cwd (current working
 * directory).  Don't forget to down the refcount to the old cwd (vput()) and
 * up the refcount to the new cwd (open_namev() or vget()). Return 0 on
 * success.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o ENOENT
 *        path does not exist.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 *      o ENOTDIR
 *        A component of path is not a directory.
 */
int
do_chdir(const char *path)
{
        if(strlen(path) < 1)
        {
			print_err_message("do_chdir", EINVAL);
			return -EINVAL;
		}
		 
        if(strlen(path) > MAXPATHLEN)
        {
			print_err_message("do_chdir", ENAMETOOLONG);
			return -ENAMETOOLONG;
		}	
	
        vnode_t *chdir_node;
        int return_code;
        return_code = open_namev(path, O_RDONLY, &chdir_node, NULL);

        if(return_code == -ENAMETOOLONG)
        {
			print_err_message("do_chdir", ENAMETOOLONG);
			return return_code;
		}
			
        if(return_code == -ENOENT)
		{
			print_err_message("do_chdir", ENOENT);
			return return_code;
		}
			
        if(return_code == -ENOTDIR)
		{
			print_err_message("do_chdir", ENOTDIR);
			return return_code;
		}
		        
		if(!S_ISDIR(chdir_node->vn_mode))
		{
			vput(chdir_node);
			print_err_message("do_chdir", ENOTDIR);
			return -ENOTDIR;
		}       
		vput(curproc->p_cwd);
		curproc->p_cwd = chdir_node;	
        
        return return_code;
}

/* Call the readdir f_op on the given fd, filling in the given dirent_t*.
 * If the readdir f_op is successful, it will return a positive value which
 * is the number of bytes copied to the dirent_t.  You need to increment the
 * file_t's f_pos by this amount.  As always, be aware of refcounts, check
 * the return value of the fget and the virtual function, and be sure the
 * virtual function exists (is not null) before calling it.
 *
 * Return either 0 or sizeof(dirent_t), or -errno.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        Invalid file descriptor fd.
 *      o ENOTDIR
 *        File descriptor does not refer to a directory.
 */
int
do_getdent(int fd, struct dirent *dirp)
{
        if(fd < 0 || fd >= NFILES)
		{
			print_err_message("do_getdent", EBADF);
			return -EBADF;
		}

        file_t *file_to_getdent = fget(fd);
        int return_code;
        
        if(file_to_getdent == NULL)
        {
			print_err_message("do_getdent", EBADF);
			return -EBADF;
		}
		
		if(!S_ISDIR(file_to_getdent->f_vnode->vn_mode))
		{
			fput(file_to_getdent);
			print_err_message("do_getdent", ENOTDIR);
			return -ENOTDIR;
		}
        return_code = file_to_getdent->f_vnode->vn_ops->readdir(file_to_getdent->f_vnode, file_to_getdent->f_pos, dirp);
        
        if(return_code > 0)
			file_to_getdent->f_pos = file_to_getdent->f_pos + return_code;
        
        fput(file_to_getdent);
        
        if(return_code > 0)
			return sizeof(*dirp);
		
		return 0;	
}

/*
 * Modify f_pos according to offset and whence.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd is not an open file descriptor.
 *      o EINVAL
 *        whence is not one of SEEK_SET, SEEK_CUR, SEEK_END; or the resulting
 *        file offset would be negative.
 */
int
do_lseek(int fd, int offset, int whence)
{
        int remp_seek;
        
        if(fd < 0 || fd >= NFILES)
		{
			print_err_message("do_lseek", EBADF);
			return -EBADF;
		}

        file_t *file_to_seek;
        file_to_seek = fget(fd);
        
        if(!file_to_seek)
        {
			print_err_message("do_lseek", EBADF);
			return -EBADF;
		}
		
		if(whence != SEEK_SET && whence != SEEK_CUR && whence != SEEK_END)
		{
			fput(file_to_seek);
			print_err_message("do_lseek", EINVAL);
			return -EINVAL;
		}
		
		if(whence == SEEK_SET)
		{
			remp_seek = file_to_seek->f_pos;
			file_to_seek->f_pos = offset;
		}
		
		if(whence == SEEK_CUR)
		{
			remp_seek = file_to_seek->f_pos;
			file_to_seek->f_pos = file_to_seek->f_pos + offset;
		}	
			
		if(whence == SEEK_END)
		{
			remp_seek = file_to_seek->f_pos;
			file_to_seek->f_pos = file_to_seek->f_vnode->vn_len + offset;
		}
		
		if(file_to_seek->f_pos < 0)
		{
			file_to_seek->f_pos = remp_seek;
			fput(file_to_seek);
			print_err_message("do_lseek", EINVAL);
			return -EINVAL;
		}
				
        fput(file_to_seek);
        return file_to_seek->f_pos;
}

/*
 * Find the vnode associated with the path, and call the stat() vnode operation.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o ENOENT
 *        A component of path does not exist.
 *      o ENOTDIR
 *        A component of the path prefix of path is not a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 */
int
do_stat(const char *path, struct stat *buf)
{
        if(strlen(path) < 1)
        {
			print_err_message("do_stat", EINVAL);
			return -EINVAL;
		}
		 
        if(strlen(path) > MAXPATHLEN)
        {
			print_err_message("do_stat", ENAMETOOLONG);
			return -ENAMETOOLONG;
		}
        
        vnode_t *stat_dir_vnode;
        int return_code;
        
        return_code = open_namev(path, O_RDONLY, &stat_dir_vnode, NULL);

        if(return_code == -ENAMETOOLONG)
        {
			print_err_message("do_stat", ENAMETOOLONG);
			return return_code;
		}
			
        if(return_code == -ENOENT)
		{
			print_err_message("do_stat", ENOENT);
			return return_code;
		}
			
        if(return_code == -ENOTDIR)
		{
			vput(stat_dir_vnode);
			print_err_message("do_stat", ENOTDIR);
			return return_code;
		}
		KASSERT(stat_dir_vnode->vn_ops->stat);		
		return_code = stat_dir_vnode->vn_ops->stat(stat_dir_vnode, buf);
		 if(return_code < 0)
		 {
			vput(stat_dir_vnode);
			print_err_message("do_lseek", (return_code * -1));
			return return_code;	
        }
        vput(stat_dir_vnode);
        return return_code;
}

#ifdef __MOUNTING__
/*
 * Implementing this function is not required and strongly discouraged unless
 * you are absolutely sure your Weenix is perfect.
 *
 * This is the syscall entry point into vfs for mounting. You will need to
 * create the fs_t struct and populate its fs_dev and fs_type fields before
 * calling vfs's mountfunc(). mountfunc() will use the fields you populated
 * in order to determine which underlying filesystem's mount function should
 * be run, then it will finish setting up the fs_t struct. At this point you
 * have a fully functioning file system, however it is not mounted on the
 * virtual file system, you will need to call vfs_mount to do this.
 *
 * There are lots of things which can go wrong here. Make sure you have good
 * error handling. Remember the fs_dev and fs_type buffers have limited size
 * so you should not write arbitrary length strings to them.
 */
int
do_mount(const char *source, const char *target, const char *type)
{
        NOT_YET_IMPLEMENTED("MOUNTING: do_mount");
        return -EINVAL;
}

/*
 * Implementing this function is not required and strongly discouraged unless
 * you are absolutley sure your Weenix is perfect.
 *
 * This function delegates all of the real work to vfs_umount. You should not worry
 * about freeing the fs_t struct here, that is done in vfs_umount. All this function
 * does is figure out which file system to pass to vfs_umount and do good error
 * checking.
 */
int
do_umount(const char *target)
{
        NOT_YET_IMPLEMENTED("MOUNTING: do_umount");
        return -EINVAL;
}
#endif
