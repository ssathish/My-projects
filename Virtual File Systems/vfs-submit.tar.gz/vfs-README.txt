-----------------------------------------------------------------------------------------------------------------------------------------------------------------

Team Members:
-------------

Sasitharan Jayagopal
Vinodh Sankaravadivel
Karthik Ramasamy
Sathish Srinivasan

Equal share split
------------------

Note:Currently the DRIVERS and VFS is set to 1 in config.mk

vfstest.c - TESTCASES
-----------------------

We have written 6 testcases which has valid dbg statements which can be read by using 'grep TESTCASE2'. While the seventh testcase we have run the testcases in file - weenix/kernel/test/vfstest/vfstest.c.

We did not modify any line in the file and our implementation passed all tests.

tests completed:
		506 passed
		0 failed
		
We have also added commands in kshell which can be used to run the individual test cases seperately.

Below is the list of commands you need to know for running the testcases through kshell

test_1  - run 'do_testcase_1' testcases
test_2  - run 'do_testcase_2' testcases
test_3  - run 'do_testcase_3' testcases
test_4  - run 'do_testcase_4' testcases
test_5  - run 'do_testcase_5' testcases
test_6  - run 'do_testcase_6' testcases
vfstest - run 'vfstest.c' testcases

You can also type help when kshell opens to see the list of commands. You can also use the vfstest command to invoke your testcase file (my_vfstest.c).

For Your Information:
-----------------------
vfstest command calls - vfstest_main()

DBG statements:
--------------

When executed normally( not from kshell)
1.)dbg statements for the expected KASSERTS are preceeded by "GRADING2 x.y".
2.)dbg statements for the testcases are preceeded by "TESTCASE2" will be printed on terminal for testcases 1 to 6 but not for the testcases in vfstest.c (since there will huge number of dbg statements fying on the screen.).

When executed from kshell
1.)dbg statements for the testcases are prceeded by "TESTCASE -" will be printed on terminal
2.)dbg statements for the expected KASSERTS will not be printed.

------------------------------------------------
Testcase 1: Error handling for mkdir,chdir,rmdir
------------------------------------------------
*Process and a thread is created for this testcase
*Current working directory "root" 
*Current directory structure: 
	root/
		->proc/
			->new1/
 				->test1.txt
 				->test2/
 			->new2/
 				->bingo1/
 				->bingo2.txt
 				->bingo3/
 			->new3/
 				->cs402/
 					->sample.txt
 		->dev/
 			->tty0
 			->null
 			->zero

Error cases tested in mkdir:
----------------------------
1.)	Testcase scenario: Trying to create already existing directory "cs402" 
	Result:Make directory failed with return code EEXIST
	
2.)	Testcase scenario: Trying to create a directory "Documents" where some component along the path "/proc/new2/bingo6/Documents" does not exist
	Result:Make directory failed with return code ENOENT 
	
3.)	Testcase scenario: Trying to create a directory "Documents" where some component along the path "/proc/new1/test1.txt/Documents" is not a directory
	Result:Make directory failed with return code ENOTDIR
	
4.)	Testcase scenario: Trying to create a directory "DocumentsIsTheNewDirectoryToBeCreated" where name is too long
	Result:Make directory failed with return code ENAMETOOLONG

Error cases tested in chdir:
----------------------------
1.)	Testcase scenario: Trying to change current working directory where some component in the path "/proc/new2/bingo6" does not exist 
	Result:Change directory failed with return code ENOENT
	 
2.)	Testcase scenario: Trying to change current working directory where some component in the path "/proc/new1/test1.txt" is not a directory
	Result:Change directory failed with return code ENOTDIR
	 
3.)	Testcase scenario: Trying to create a directory "DocumentsIsTheNewDirectoryToBeCreated" where name is too long 
	Result:Change directory failed with return code ENAMETOOLONG 

Error cases tested in rmdir:
----------------------------
1.)	Testcase scenario: Trying to change current working directory where some component in the path "/proc/new2/bingo6" does not exist 
	Result:Change directory failed with return code ENOENT

2.)	Testcase scenario: Trying to remove a directory "Documents" where some component along the path "/proc/new1/test1.txt/Documents" is not a directory
	Result:Change directory failed with return code ENOTDIR
 
3.)	Testcase scenario: Trying to create a directory "DocumentsIsTheNewDirectoryToBeCreated" where name is too long 
	Result:Change directory failed with return code ENAMETOOLONG 
	
*Process created for this testcases gracefully terminates


------------------------------------------------------------------------
Testcase 2:Testing the correctness of lseek, read and write system calls
------------------------------------------------------------------------
*Process and a thread is created for this testcase

Testcase creation & Results:

*A directory named "testing" is created
*A file named "vfs" is created ane opened  in O_RDWR mode inside the "testing" directory
*Writing text "First Sentence ends here" into the file
*Seek to start of file with SEEK_SET zero
*Read from the contents of file and the result is displayed which shows "First Sentence ends here"
*Seeking to position 5 using SEEK_SET
*Writing text into file "Second sentence inserted here"
*Seek to start of file with SEEK_SET 
*Read from the contents of file and the result is displayed which shows  "FirstSecond sentence inserted here"
*Without closing the file now it is seeked to SEEK_CUR which will be at the  end of the file
*Writing text "Cursor Text" is here" into file 
*Seek to start of file with SEEK_SET zero
*Read from the contents of file and the result is displayed which shows "FirstSecond sentence inserted hereCursor Text is here"
*Seek to end of file with SEEK_END
*Write into the file "New Text is written at the end
*Seek to start of file with SEEK_SET zero
*Read from the contents of file and the result is displayed which shows "FirstSecond sentence inserted hereCursor Text is hereNew Text is written at the end"
*Closing the file
*Removing the directory "testing" created 
		
*Process created for this testcases gracefully terminates
	


---------------------------------------------------
Testcase 3: Error handling for open,dup,dup2,close
--------------------------------------------------
*Process and a thread is created for this testcase
*Current working directory "root" 
*Current directory structure: 
	root/
		->proc/
			->new1/
 				->test1.txt
 				->test2/
 			->new2/
 				->bingo1/
 				->bingo2.txt
 				->bingo3/
 			->new3/
 				->cs402/
 					->sample.txt
 		->dev/
 			->tty0
 			->null
 			->zero

Error cases tested in open:
---------------------------
1.)	Testcase scenario:Trying to open which does not exist and O_CREAT flag is not set
	Result:open failed with return code ENOENT

2.)	Testcase scenario:Trying to open with invalid oflags paramater
	Result:open failed with return code EINVAL
	
3.)	Testcase scenario:Trying to open more files than the max allowed per process
	Testcase creation:
		*Currently the process has no open files
		*So max allowed files per process is created and opened. Filename is "/proc/new2/rand%.txt" (where % is 1 to 32)
		*Now process has reached max amount of files that can be opened.Trying to dup same file once more now.
			
	Result:	*Open failed with return code EMFILE
			*All open files are closed and unlinked
	
4.)	Testcase scenario:Trying to open a file "ThisIsTheNewFileToBeCreatedAndOpened" where name is too long with O_CREAT flag set
	Result:Open failed with return code ENAMETOOLONG 

5.)	Testcase scenario:Trying to open a directory "cs402"
	Result:Open failed with return code EISDIR
	
Error cases tested in dup:
--------------------------
1.)	Testcase scenario:Trying to dup a file which has invalid fd number
	Result:dup failed with return code EBADF
	
2.)	Testcase scenario:Trying to dup more files than the max allowed per process
	Testcase creation:
		*Currently the process has no open files
		*So a file is created with do_open system call with O_CREAT flag set
		*Now the created file is dup'ed to reach the max allowed fd per process
		*Now process has reached max amount of files that can be opened.Trying to dup same file once more now...
		
	Result:	*Dup failed with return code EMFILE
			*All open and dup'ed files are closed
			
Error cases tested in dup2:
---------------------------
1.)	Testcase scenario:Trying to dup2 a file which has invalid ofd number
	Result:dup2 failed with return code EBADF
	
2.)	Testcase scenario:Trying to dup2 a file which has invalid nfd number
	Result:dup2 failed with return code EBADF
	
Error cases tested in close:
----------------------------
1.)	Testcase scenario:Trying to close a file which has invalid fd number
	Result:Close failed with return code EBADF
	
*Process created for this testcases gracefully terminates
		

Testcase 4: linking and renaming files
-----------------------------------------

Description:
------------
*Created a directory 'testcase_4' by calling do_mkdir() function; changed processes's current working directory to 'testcase_4' by calling do_chdir() function.
*Created two more directories 'SASI' and 'SATHISH' and a file 'file01.txt' with read & write access inside 'SASI'.
*Changed processes's current working directory to the parent directory (ie., root directory where 'testcase_4' is present)
*Called ls function which prints the list of directories/ files present inside 'testcase-5'.
*Now directory 'SASI' contains 'file01.txt' while directory 'SATHISH' is empty.
*Calling do_link() function to create a link from SASI/file01.txt to 'SATHISH/file02.txt'.
*A new file 'SATHISH/file02.txt' is created which links from 'SASI/file01.txt' 
*changing into directory 'SASI' and calling do_rename() to rename the file 'file01.txt' to 'file03.txt'
*The entries inside 'SATHISH' will be printed before and after link operation to show link operation works well
*The entries inside 'SASI' will be printed before and after rename operation to show rename operation works well
*deleted files inside 'SASI' and 'SATHISH' and finally the directories 'SASI' and 'SATHISH'
**deleted 'testcase_4' successfully and this ends our testcase.

Functions used:
---------------
1.)do_mkdir
2.)do_chdir
3.)do_open
4.)do_getdents
5.)do_stat
6.)do_rmdir
7.)do_unlink
8.)open_namev
9.)dir_namev
10.)lookup
11.)do_link
12.)do_rename


Testcase 5: making, removing directories; opening/creating and unlinking files; implented our version of 'ls' to list all contents inside a directory
-------------------------------------------------------------------------------------------------------------------------------------------------------

Description:
------------
*Created a directory 'testcase_5' by calling do_mkdir() function; changed processes's current working directory to 'testcase_5' by calling do_chdir() function.
*Created two more directories 'SASI' and 'SATHISH' and a file 'file01.txt' with read & write access inside 'testcase_5'.
*Changed processes's current working directory to the parent directory (ie., root directory where 'testcase_5' is present)
*Called ls function which prints the list of directories/ files present inside 'testcase-5'.
*ls function uses do_getdent() to get one directory/ file structure present in the given directory path and do_stat() function on each obtained directory/ file structure to determine if it is a file or directory. Directories are appended with '/' at the end while files will have just their names.  
*Tried deleting the directory 'testcase_5' but returned with an error message - DIRECTORY NOT EMPTY.
*changed processes's current working directory back to 'testcase_5'.
*Tried creating another directory with same name 'SASI' which returned with an error - DIRECTORY ALREADY EXISTS.
*called do_rmdir() on 'SASI' and 'SATHISH' and finally an do_unlink() on file01.txt, deleting all components.
*Changed processes's current working directory to the parent directory and called do_rmdir() on 'testcase_5'
*deleted 'testcase_5' successfully and this ends our testcase.

Functions used:
---------------
1.)do_mkdir
2.)do_chdir
3.)do_open
4.)do_getdents
5.)do_stat
6.)do_rmdir
7.)do_unlink
8.)open_namev
9.)dir_namev
10.)lookup


Testcase 6: tests on do_dup, do_dup2 and do_close of files
-----------------------------------------------------------

Description:
------------
*Created a directory 'testcase_6' by calling do_mkdir() function; changed processes's current working directory to 'testcase_6' by calling do_chdir() function.
*Created three files 'file01.txt', 'file02.txt', 'file03.txt' on file descriptors 0, 1, 2.
*Calling do_dup() function on fd's  -  0, 1, 2 and file descriptors  - 3, 4, 5 are created (3,4 & 5 are the next available fds).
*fds 0 and 3 point to the same file structure, 1 and 4 point to the same file structure and 2 and 4 point to the same file structure.
*also printed the reference count of the files which in now 2.

*calling do_dup2() to duplicate fd - '0' with fd of already opened file descriptor '5'.
*fd - 5 points to a valid file structure (to file pointed to by fd - 2) which is now closed by calling do_close and the fd - 5 now points to file pointed to by fd - 0.
*All three files are now unliked by calling do_unlink.
*Changed processes's current working directory to the parent directory and called do_rmdir() on 'testcase_6'
*deleted 'testcase_6' successfully and this ends our testcase.

Functions used: 
---------------
1.)do_mkdir
2.)do_chdir
3.)do_open
4.)do_rmdir
5.)do_unlink
6.)open_namev
7.)dir_namev
8.)lookup
9.)do_dup
10.)do_dup2
11._do_close


Testcase 7: Run testcases in vfstest.c
---------------------------------------

Our code passes all tests provided in the vfstest.c file (which is not modified).

Testcase 8: Demonstrate testcases in KSHELL
---------------------------------------------

*A new process for KSHELL creation and command execution is created from the INIT process and is represented by a special file in /dev directory named /dev/tty0. This is done through the function
	
	do_mknod().
 
*When the kshell process starts a Kshell is created and it prompts for commands to be entered by the User.
*Commands read and written on to the KSHELL are through functions 
	
	special_file_read() and 
	special_file_write().  

When the testcases are executed from KSHELL it runs in a mode such that the dbg statements (starting with "GRADING X.Y") after KASSERT doesnot execute. Only the dbg statements that we have used to explain the flow of testcases will be executed and printed. This we have done so that it will be easy for you to understand the flow easily. 

This concludes all our testcases implemented to test the correct functioning of the VFS functions implemeted.

****************************************************************************************************************************************************************
****************************************************************************************************************************************************************
